package Persistence;

import Business.*;
import Business.Character;
import java.util.ArrayList;

/**
 * This class is made to parse the Character class because there are some problems on saving it from the JSON file
 * because it is an abstract class
 */
public class CharacterParse {
    private String name;
    private String player;
    private int body;
    private int mind;
    private int spirit;
    private String characterClass;
    private int xp;
    private int level;
    private int hitPoints;
    private String damageType;
    private int maxHP;
    private Dice dice;
    private int shield;

    /**
     * this function parses all the information of one cell of the Character array that takes all the info from the CHARACTER.JSON
     * and adds it to the allCharacters ArrayList
     * @param allCharacters ArrayList of all the Characters
     */
    public void parseCharacter(ArrayList<Character> allCharacters) {
        switch (this.characterClass) {
            case "Adventurer" -> allCharacters.add(new Adventurer(this.name, this.body, this.mind, this.spirit, this.level, this.player, this.characterClass));
            case "Warrior" -> allCharacters.add(new Warrior(this.name, this.body, this.mind, this.spirit, this.level, this.player, this.characterClass));
            case "Champion" -> allCharacters.add(new Champion(this.name, this.body, this.mind, this.spirit, this.level, this.player, this.characterClass));
            case "Cleric" -> allCharacters.add(new Cleric(this.name, this.body, this.mind, this.spirit, this.level, this.player, this.characterClass));
            case "Paladin" -> allCharacters.add(new Paladin(this.name, this.body, this.mind, this.spirit, this.level, this.player, this.characterClass));
            case "Wizard" -> allCharacters.add(new Wizard(this.name, this.body, this.mind, this.spirit, this.level, this.player, this.characterClass));
        }
    }
}
