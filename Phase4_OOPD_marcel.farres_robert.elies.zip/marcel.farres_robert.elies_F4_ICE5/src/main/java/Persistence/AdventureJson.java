package Persistence;

import Business.Adventure;
import com.google.gson.Gson;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * This class is in charge of reading and writing a JSON file with the information of the adventures
 */
public class AdventureJson implements AdventureDAO{

    /**
     * Reads the whole adventure file
     * @return ArrayList with the all the adventures
     */
    @Override
    public ArrayList<Adventure> readFileAdventure() {
        Gson gson = new Gson();
        ArrayList<Adventure> allAdventures = new ArrayList<>();
        File jsonFileEdition = new File("C:\\Users\\TESTER\\Desktop\\test\\marcel.farres_robert.elies_F4_ICE5\\adventures.json");
        if (jsonFileEdition.isFile()) {
            try{
                BufferedReader jsonReader = new BufferedReader(new FileReader("adventures.json"));
                Adventure[] adventureArr = gson.fromJson(jsonReader, Adventure[].class);
                allAdventures.addAll(Arrays.asList(adventureArr));
                jsonReader.close();
                return allAdventures;
            }catch (Exception e){
                e.printStackTrace();
                return null;
            }
        }else{
            return null;
        }
    }

    /**
     * writes a new adventure created by the user to the file
     * @param newAdventure adventure recently created
     */
    @Override
    public void updateAdventures(Adventure newAdventure){
        FileWriter f;
        ArrayList<Adventure> allAdventures = new ArrayList<>();
        if(readFileAdventure() != null){
            allAdventures = (ArrayList<Adventure>) readFileAdventure().clone();
        }
        allAdventures.add(newAdventure);
        try{
            Gson gson = new Gson();
            f = new FileWriter("adventures.json");
            Adventure[] arr = new Adventure[allAdventures.size()];
            for(int i = 0; i < allAdventures.size(); i++){
                arr[i] = allAdventures.get(i);
            }
            String jsonString = gson.toJson(arr, Adventure[].class);
            f.append(jsonString);
            f.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
