package Persistence;

import Business.Character;
import com.google.gson.Gson;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * This class is in charge of reading, writing the JSON file with the information of the characters
 * and to delete specific characters
 */
public class CharacterJson implements CharacterDAO{
    /**
     * reads the whole character file
     * @return ArrayList of all the characetrs in the file
     */
    @Override
    public ArrayList<Character> readFileCharacter() {
        ArrayList<Character> allCharacters = new ArrayList<>();
        File jsonFileEdition = new File("C:\\Users\\TESTER\\Desktop\\test\\marcel.farres_robert.elies_F4_ICE5\\characters.json");
        if (jsonFileEdition.isFile()) {
            try{
                Gson gson = new Gson();
                BufferedReader jsonReader = new BufferedReader(new FileReader("characters.json"));
                CharacterParse[] characterArr = gson.fromJson(jsonReader, CharacterParse[].class);
                for (CharacterParse characterJSON : characterArr) {
                    characterJSON.parseCharacter(allCharacters);
                }
                jsonReader.close();
                return allCharacters;
            }catch (Exception e){
                e.printStackTrace();
                return null;
            }
        }else{
            return null;
        }
    }

    /**
     * writes a new character on the character file
     * @param newCharacter new character created by the user to add
     */
    @Override
    public void updateCharacters(Character newCharacter){
        FileWriter f;
        ArrayList<Character> allCharacters = new ArrayList<>();
        if(readFileCharacter() != null){
            allCharacters = (ArrayList<Character>) readFileCharacter().clone();
        }
        allCharacters.add(newCharacter);
        try{
            Gson gson = new Gson();
            f = new FileWriter("characters.json");
            Character[] arr = new Character[allCharacters.size()];
            for(int i = 0; i < allCharacters.size(); i++){
                arr[i] = allCharacters.get(i);
            }
            String jsonString = gson.toJson(allCharacters);
            f.write(jsonString);
            f.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    /**
     * removes a character from the file of characters
     * @param c Character to delete
     */
    @Override
    public void removeCharacter(Character c, int index) {
        Gson gson = new Gson();
        FileWriter f;
        ArrayList<Character> allCharacters = new ArrayList<>();
        File jsonFileEdition = new File("C:\\Users\\TESTER\\Desktop\\test\\marcel.farres_robert.elies_F4_ICE5\\characters.json");
        if (jsonFileEdition.isFile()) {
            try {
                BufferedReader jsonReader = new BufferedReader(new FileReader("characters.json"));
                CharacterParse[] characterArr = gson.fromJson(jsonReader, CharacterParse[].class);
                for (CharacterParse characterJSON : characterArr) {
                    characterJSON.parseCharacter(allCharacters);
                }
                jsonReader.close();
                allCharacters.removeIf(a -> a.getName().equals(c.getName()));
                f = new FileWriter("characters.json");
                Character[] arr = new Character[allCharacters.size()];
                for (int i = 0; i < allCharacters.size(); i++) {
                    arr[i] = allCharacters.get(i);
                }
                String jsonString = gson.toJson(arr, Character[].class);
                f.write(jsonString);
                f.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

