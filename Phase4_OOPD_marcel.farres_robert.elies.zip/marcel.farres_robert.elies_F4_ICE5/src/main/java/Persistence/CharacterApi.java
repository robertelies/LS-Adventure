package Persistence;

import Business.Character;
import com.google.gson.Gson;
import java.util.ArrayList;

/**
 * This class is in charge of reading, writing on the API with the information of the characters
 * and to delete specific characters
 */
public class CharacterApi implements CharacterDAO{
    private ApiHelper apiHelper;

    /**
     * reads the whole character file
     * @return ArrayList of all the characetrs in the file
     */
    @Override
    public ArrayList<Character> readFileCharacter(){
        try{
            apiHelper = new ApiHelper();
            String content = apiHelper.getFromUrl("https://balandrau.salle.url.edu/dpoo/S1_Project_ICE5/characters");
            Gson gson = new Gson();
            CharacterParse[] characterArr = gson.fromJson(content, CharacterParse[].class);
            ArrayList<Character> allCharacters = new ArrayList<>();
            for (CharacterParse characterJSON : characterArr) {
                characterJSON.parseCharacter(allCharacters);
            }
            return allCharacters;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /**
     * removes a character from the file of characters
     * @param c Character to delete
     * @param index the position in the array of Characters of the Character to remove
     */
    @Override
    public void removeCharacter(Character c, int index) {
        try{
            apiHelper = new ApiHelper();
            String url = "https://balandrau.salle.url.edu/dpoo/S1_Project_ICE5/characters/" + index;
            String content = apiHelper.deleteFromUrl(url);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     * writes a new character on the character file
     * @param mainCharacter new character created by the user to add
     */
    @Override
    public void updateCharacters(Character mainCharacter){
        try{
            Gson gson = new Gson();
            apiHelper = new ApiHelper();
            String body = gson.toJson(mainCharacter);
            String content = apiHelper.postToUrl("https://balandrau.salle.url.edu/dpoo/S1_Project_ICE5/characters", body);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
