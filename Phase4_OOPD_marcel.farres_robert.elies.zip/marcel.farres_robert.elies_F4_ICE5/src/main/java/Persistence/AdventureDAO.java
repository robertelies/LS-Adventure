package Persistence;

import Business.Adventure;
import java.util.ArrayList;

/**
 * Interface for the Adventure Persistence Classes
 */
public interface AdventureDAO {

    /**
     * Reads the whole adventure file
     * @return ArrayList with the all the adventures
     */
    ArrayList<Adventure> readFileAdventure();

    /**
     * writes a new adventure created by the user to the file
     * @param newAdventure adventure recently created
     */
    void updateAdventures(Adventure newAdventure);
}

