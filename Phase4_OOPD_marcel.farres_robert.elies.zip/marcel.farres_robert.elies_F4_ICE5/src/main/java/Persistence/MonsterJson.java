package Persistence;

import Business.Monster;
import com.google.gson.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * This class makes the Monster Persistence on JSON format
 */
public class MonsterJson implements MonsterDAO{

    /**
     * Opens and checks if the monster file exists
     */
    @Override
    public boolean openFileMonster() {
        File jsonFileEdition = new File("C:\\Users\\TESTER\\Desktop\\test\\marcel.farres_robert.elies_F4_ICE5\\monsters.json");
        if (jsonFileEdition.isFile() && jsonFileEdition.exists()) {
            try{
                BufferedReader jsonReader = new BufferedReader(new FileReader("monsters.json"));
                jsonReader.close();
                return true;
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return false;
    }

    /**
     * reads the whole Monster file
     * @return ArrayList with all the monsters from the file
     */
    @Override
    public ArrayList<Monster> readFileMonster() {
        Gson gson = new Gson();
        ArrayList<Monster> allMonsters = new ArrayList<>();
        File jsonFileEdition = new File("C:\\Users\\TESTER\\Desktop\\test\\marcel.farres_robert.elies_F4_ICE5\\monsters.json");
        if (jsonFileEdition.isFile()) {
            try{
                BufferedReader jsonReader = new BufferedReader(new FileReader("monsters.json"));
                Monster[] monsterArr = gson.fromJson(jsonReader, Monster[].class);
                allMonsters.addAll(Arrays.asList(monsterArr));
                jsonReader.close();
                return allMonsters;
            }catch (Exception e){
                e.printStackTrace();
                return null;
            }
        }
        return null;
    }
}