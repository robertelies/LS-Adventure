package Persistence;

import Business.Character;
import java.util.ArrayList;

/**
 * Interface for the Character Persistence Classes
 */
public interface CharacterDAO {

    /**
     * reads the whole character file
     * @return ArrayList of all the characetrs in the file
     */
    ArrayList<Character> readFileCharacter();

    /**
     * removes a character from the file of characters
     * @param c Character to delete
     * @param index the position in the array of Characters of the Character to remove
     */
    void removeCharacter(Character c, int index);

    /**
     * writes a new character on the character file
     * @param newCharacter new character created by the user to add
     */
    void updateCharacters(Character newCharacter);
}
