package Persistence;

import Business.Adventure;
import com.google.gson.Gson;
import java.util.ArrayList;


/**
 * This class is in charge of reading and writing to the API with the information of the adventures
 */
public class AdventureApi implements AdventureDAO{
    private ApiHelper apiHelper;

    /**
     * Reads the whole adventure file
     * @return ArrayList with the all the adventures
     */
    @Override
    public ArrayList<Adventure> readFileAdventure(){
        try{
            apiHelper = new ApiHelper();
            String content = apiHelper.getFromUrl("https://balandrau.salle.url.edu/dpoo/S1_Project_ICE5/adventures");
            Gson gson = new Gson();
            Adventure[] adventureArr = gson.fromJson(content, Adventure[].class);
            ArrayList<Adventure> allAdventures = new ArrayList<>();
            for(Adventure a: adventureArr){
                Adventure newOne = new Adventure(a.getName(), a.getAllEncounters());
                allAdventures.add(newOne);
            }
            return allAdventures;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /**
     * writes a new adventure created by the user to the file
     * @param newAdventure adventure recently created
     */
    @Override
    public void updateAdventures(Adventure newAdventure) {
        try{
            Gson gson = new Gson();
            apiHelper = new ApiHelper();
            String body = gson.toJson(newAdventure);
            String content = apiHelper.postToUrl("https://balandrau.salle.url.edu/dpoo/S1_Project_ICE5/adventures", body);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
