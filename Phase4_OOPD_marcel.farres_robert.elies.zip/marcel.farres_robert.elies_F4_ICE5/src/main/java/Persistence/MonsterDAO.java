package Persistence;

import Business.Monster;
import java.util.ArrayList;

/**
 * Interface for the Monster Persistence Classes
 */
public interface MonsterDAO {

    /**
     * Opens and checks if the monster file exists
     */
    boolean openFileMonster();

    /**
     * reads the whole Monster file
     * @return ArrayList with all the monsters from the file
     */
    ArrayList<Monster> readFileMonster();
}
