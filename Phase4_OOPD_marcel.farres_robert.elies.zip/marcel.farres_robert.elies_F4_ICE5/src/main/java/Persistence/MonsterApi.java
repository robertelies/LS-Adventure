package Persistence;

import Business.Monster;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Arrays;

public class MonsterApi implements MonsterDAO{
    private ApiHelper apiHelper;

    /**
     * Opens and checks if the monster file exists
     */
    @Override
    public boolean openFileMonster(){
        try{
            apiHelper = new ApiHelper();
            apiHelper.getFromUrl("https://balandrau.salle.url.edu/dpoo/shared/monsters");
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

    /**
     * reads the whole Monster file
     * @return ArrayList with all the monsters from the file
     */
    @Override
    public ArrayList<Monster> readFileMonster(){
        try{
            apiHelper = new ApiHelper();
            String content = apiHelper.getFromUrl("https://balandrau.salle.url.edu/dpoo/shared/monsters");
            Gson gson = new Gson();
            Monster[] monsterArr = gson.fromJson(content, Monster[].class);
            ArrayList<Monster> allMonsters = new ArrayList<>(Arrays.asList(monsterArr));
            return allMonsters;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

}
