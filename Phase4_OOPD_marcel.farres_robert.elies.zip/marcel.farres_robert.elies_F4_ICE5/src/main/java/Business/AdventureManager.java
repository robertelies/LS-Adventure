package Business;

import Persistence.*;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * This class manages the operations related with the adventure
 */
public class AdventureManager {
    private AdventureDAO adventureDAO;
    private Dice dice;
    private Adventure currentAdventure;
    private ArrayList<Encounter> creatingEncounters;
    private ArrayList<ParticipantsAdventure> allParticipants;
    private ArrayList<Integer> initiativeOrder;
    private ArrayList<Character> adventureCharacters;
    private ArrayList<Integer> originalHitPoints;
    private ArrayList<Integer> healingPoints;
    private CharacterManager characterManager;

    //constructor

    /**
     * constructor of the Adventure Manager, creates the necessary arrayLists, dice class, and how are we going
     * to retrieve the information on Persistence
     * @param typeOfData int that decided by the user chooses which type of persistence are we using on the game
     */
    public AdventureManager(int typeOfData){
        dice = new Dice();
        characterManager = new CharacterManager(typeOfData);
        creatingEncounters = new ArrayList<>();
        adventureCharacters = new ArrayList<>();
        originalHitPoints = new ArrayList<>();
        allParticipants = new ArrayList<>();
        initiativeOrder = new ArrayList<>();
        healingPoints = new ArrayList<>();
        if(typeOfData == 1){
            adventureDAO = new AdventureJson();
        }else{
            adventureDAO = new AdventureApi();
        }
    }
//methods

    /**
     * checkst that the name of the adventure is unique
     * @param adventureName name of the adventure
     * @return true if the name is not unique
     */
    public boolean checkUnique(String adventureName) {
        if (adventureDAO.readFileAdventure() != null) {
            for (Adventure c : adventureDAO.readFileAdventure()) {
                if (adventureName.equals(c.getName())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * creates new encounter
     * @param encounterMonsters ArrayList of monsters from the encounter
     * @param numMonsters ArrayList of number of monsters from the encounter
     * @return new encounter
     */
    public ArrayList<Encounter> createEncounter(ArrayList<Monster> encounterMonsters, ArrayList<Integer> numMonsters) {
        Encounter e = new Encounter(encounterMonsters, numMonsters);
        creatingEncounters.add(e);
        return creatingEncounters;
    }

    /**
     * checks if there is an existing boss in the encounter
     * @param encounterMonsters monsters from the encounter
     * @return true if there is a boss in the encounter monsters
     */
    public boolean getBoss(ArrayList<Monster> encounterMonsters) {
        for(Monster m: encounterMonsters){
            if(m.getChallenge().equals("Boss")){
                return true;
            }
        }
        return false;
    }

    /**
     * deletes a monster from the encounter
     * @param encounterMonsters ArrayList of monster from the encounter
     * @param numMonsters ArrayList of number of monsters from the encounter
     * @param numDelete position of the ArrayList to delete
     */
    public void deleteMonsters(ArrayList<Monster> encounterMonsters, ArrayList<Integer> numMonsters, int numDelete) {
        encounterMonsters.remove(numDelete - 1);
        numMonsters.remove(numDelete - 1);
    }

    /**
     * creates a new adventure
     * @param adventureName name of the adventure
     * @param numEncounters number of encounters
     * @param encounters ArrayList with all the encounters
     */
    public void createAdventure(String adventureName, int numEncounters, ArrayList<Encounter> encounters) {
        Adventure a = new Adventure(adventureName, numEncounters, encounters);
        adventureDAO.updateAdventures(a);
    }

    /**
     * @return all the adventures names
     */
    public ArrayList<String> getAllAdventuresName() {
        ArrayList<String> names = new ArrayList<>();
        for(Adventure a: adventureDAO.readFileAdventure()){
            names.add(a.getName());
        }
        return names;
    }

    /**
     * sets which one is the current adventure
     * @param numAdventure number of adventure to set as current
     */
    public void setCurrentAdventure(int numAdventure) {
        currentAdventure = new Adventure(adventureDAO.readFileAdventure().get(numAdventure));
    }

    /**
     * @return name of current adventure
     */
    public String getCurrentAdventureName() {
        return currentAdventure.getName();
    }

    /**
     * @return all the names of the characters from the adventure
     */
    public ArrayList<String> getAdventureCharactersName() {
        ArrayList<String> names = new ArrayList<>();
        for(Character c: adventureCharacters){
            names.add(c.getName());
        }
        return names;
    }

    /**
     * sets a character into the adventure party
     * @param index position in the arraylist of all characters
     * @param allCharacters arraylist of all characters
     */
    public void setCharacter(int index, ArrayList<Character> allCharacters) {
        adventureCharacters.add(allCharacters.get(index));
    }

    /**
     * @return true if all characters are dead
     */
    public boolean battleLost() {
        int counter = 0;
        for (Character adventureCharacter : adventureCharacters) {
            if (adventureCharacter.getHitPoints() < 1) {
                counter++;
            }
        }
        return counter == adventureCharacters.size();
    }

    /**
     * @return number of encounters of the current adventure
     */
    public int getNumberOfEncounters() {
        return currentAdventure.getNumEncounters();
    }

    /**
     * @param i number of encounter
     * @return the desired encounter in the ArrayList of encounters from the current adventure
     */
    public Encounter getEncounter(int i) {
        return currentAdventure.getAllEncounters().get(i);
    }

    /**
     * Creates an ArrayList of Participants (monsters + characters) for the adventure
     * @param i number of encounter
     */
    public void createParticipants(int i) {
        for (Character c : adventureCharacters) {
            if(c.getHitPoints() >= 1){
                int result;
                if(c.getCharacterClass().equals("Adventurer")|| c.getCharacterClass().equals("Warrior") || c.getCharacterClass().equals("Champion")){
                    result = dice.rollDice(12) + c.getSpirit();
                }else{
                    if(c.getCharacterClass().equals("Cleric") || c.getCharacterClass().equals("Paladin")){
                        result = dice.rollDice(10) + c.getSpirit();
                    }else{
                        result = dice.rollDice(20) + c.getMind();
                    }
                }
                initiativeOrder.add(result);
                allParticipants.add(c);
            }
        }
        for (int m = 0; m < currentAdventure.getAllEncounters().get(i).getMonsters().size(); m++) {
            for(int k = 0; k < currentAdventure.getAllEncounters().get(i).getNumberMonsters().get(m); k++){
                int result = dice.rollDice(12) + currentAdventure.getAllEncounters().get(i).getMonsters().get(m).getInitiative();
                initiativeOrder.add(result);
                allParticipants.add(currentAdventure.getAllEncounters().get(i).getMonsters().get(m));
            }
        }
        int temp;
        ArrayList<ParticipantsAdventure> secondary = new ArrayList<>();
        for (int k = 0; k < initiativeOrder.size(); k++) {
            for (int j = k + 1; j < initiativeOrder.size(); j++) {
                if (initiativeOrder.get(k) < initiativeOrder.get(j)) {
                    temp = initiativeOrder.get(k);
                    secondary.add(allParticipants.get(k));

                    initiativeOrder.set(k, initiativeOrder.get(j));
                    allParticipants.set(k, allParticipants.get(j));

                    initiativeOrder.set(j, temp);
                    allParticipants.set(j, secondary.get(0));
                    secondary.clear();
                }
            }
        }
    }

    /**
     * @return all the participants from the adventure
     */
    public ArrayList<ParticipantsAdventure> getParticipants() {
        return allParticipants;
    }

    /**
     * @return the initiative order of the battle
     */
    public ArrayList<Integer> getOrder() {
        return initiativeOrder;
    }

    /**
     * checks if all mosnters are dead
     * @param j number of encounter
     * @return true if all monsters are dead
     */
    public boolean deadMonsters(int j) {
        int counter = 0;
        for (ParticipantsAdventure allParticipant : allParticipants) {
            if (!(allParticipant.isCharacter()) && (allParticipant.getHitPoints() < 1)) {
                counter++;
            }
        }
        return counter == currentAdventure.getAllEncounters().get(j).getMonsters().size();
    }

    /**
     * sets up every character for the preparation stage
     */
    public ArrayList<String> preparationStage(Character c) {
        return c.preparationChar(adventureCharacters);
    }

    /**
     * adds to an ArrayList the original HP of the characters from the adventure
     */
    public void setOriginalHitpoints() {
        for (Character adventureCharacter : adventureCharacters) {
            originalHitPoints.add(adventureCharacter.getHitPoints());
        }
    }

    /**
     * computes the xp to add the character for defeating all monsters on the encounter
     * @param j number of encounter
     * @return the xp to add
     */
    public int computeXp(int j) {
        int sum = 0;
        for(int i = 0; i < currentAdventure.getAllEncounters().get(j).getMonsters().size(); i++){
            sum = sum + currentAdventure.getAllEncounters().get(j).getMonsters().get(i).getExperience();
        }
        int num = 0;
        for(int i = 0; i < currentAdventure.getAllEncounters().get(j).getNumberMonsters().size(); i++){
            num = num + currentAdventure.getAllEncounters().get(j).getNumberMonsters().get(i);
        }
        return sum * num;
    }

    /**
     * clears all the arraylists for the next adventure
     */
    public void reset() {
        allParticipants.clear();
        initiativeOrder.clear();
        adventureCharacters.clear();
        originalHitPoints.clear();
        healingPoints.clear();
    }

    /**
     * uploads the xp and takes care if necessary to level up
     * @param addXp xp to add
     */
    public void uploadXp(int addXp) {
        Iterator<Character> iterator = adventureCharacters.iterator();
        while (iterator.hasNext()) {
            Character c = iterator.next();
            c.setXp(c.getXp() + addXp);
            if ((c.getXp() / 100) != (c.getLevel() - 1)) {
                if (c.getLevel() != 10) {
                    c.setLevel((c.getXp()/100) + 1);
                    if(c.getLevel() > 10){
                        c.setLevel(10);
                    }
                    c.redoHealthPoints();
                    if (c.getCharacterClass().equals("Adventurer") && c.getLevel() == 4) {
                        Character newC = characterManager.evolveCharacter(c, 1);
                        iterator.remove();  // Use iterator.remove() to safely remove the current element
                        adventureCharacters.add(newC);
                    }
                    else if (c.getCharacterClass().equals("Warrior") && c.getLevel() == 8) {
                        Character newC = characterManager.evolveCharacter(c, 2);
                        iterator.remove();
                        adventureCharacters.add(newC);
                    }
                    else if (c.getCharacterClass().equals("Cleric") && c.getLevel() == 5) {
                        Character newC = characterManager.evolveCharacter(c, 3);
                        iterator.remove();
                        adventureCharacters.add(newC);
                    }
                }
            }
        }
    }

    /**
     * uploads the HP
     */
    public ArrayList<String> uploadHp(Character c) {
        if(c.getHitPoints() != 0){
            return c.restChar(adventureCharacters);
        }else{
            return null;
        }
    }

    /**
     * computes who attacks who on the combat
     * @param attack position in the ArrayList of Participants
     * @return ArrayList of the attacker (position 0) and attacked (position 1)
     */
    public ArrayList<ParticipantsAdventure>  whoAttack(int attack) {
        ArrayList<ParticipantsAdventure> versus = new ArrayList<>();
        int rand;
        versus.add(allParticipants.get(attack));
        if(allParticipants.get(attack).isCharacter()){
            do{
                rand = (dice.rollDice(allParticipants.size())) - 1;
            }while((allParticipants.get(rand).isCharacter()) || (allParticipants.get(rand).equals(allParticipants.get(attack))) || (allParticipants.get(rand).getHitPoints() <= 0));
        }else{
            do {
                rand = (dice.rollDice(allParticipants.size())) - 1;
            }while(!(allParticipants.get(rand).isCharacter()) || (allParticipants.get(rand).equals(allParticipants.get(attack))) || (allParticipants.get(rand).getHitPoints() <= 0));
        }
        versus.add(allParticipants.get(rand));
        return versus;
    }

    /**
     * checks if the participant is alive
     * @param attack position in the ArrayList of Participants
     * @return true if its alive
     */
    public boolean alive(int attack) {
        return allParticipants.get(attack).getHitPoints() >= 1;
    }

    /**
     * @return ArrayList with all the characters from the adventure
     */
    public ArrayList<Character> getAdventureCharacters() {
        return adventureCharacters;
    }

    /**
     * method that searches for repeated monsters
     * @param encounterMonsters arraylist of the monsters from the encounter
     * @param monsterName name of the new monster
     * @return true if the names are repeated
     */
    public boolean getRepeatedMonster(ArrayList<Monster> encounterMonsters, String monsterName) {
        for(Monster m: encounterMonsters){
            if(m.getName().equals(monsterName)){
                return true;
            }
        }
        return false;
    }

    /**
     * clears the initiative order and the participants list after every encounter
     */
    public void resetInitiative() {
        initiativeOrder.clear();
        allParticipants.clear();
    }

    /**
     * checks if one monster is dead
     * @param versus arrayList with the names of the two character and monster that fight
     * @return true if a character just killed a monster
     */
    public boolean isKill(ArrayList<ParticipantsAdventure> versus) {
        return versus.get(1).getHitPoints() < 1;
    }

    /**
     * creates an arrayList with all the monsters of the encounter and creates an action to be able to print it later
     * @param versus the two participants that will battle
     * @return an Action that contains name, damage, and people affected
     */
    public Action newAction(ArrayList<ParticipantsAdventure> versus) {
        ArrayList<ParticipantsAdventure> encounterMonsters = new ArrayList<>();
        for(ParticipantsAdventure p : allParticipants){
            if(!p.isCharacter()){
                encounterMonsters.add(p);
            }
        }
        return versus.get(0).createAction(adventureCharacters, versus.get(1), encounterMonsters);
    }
}
