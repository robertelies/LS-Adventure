package Business;

import java.util.ArrayList;

/**
 * This class has all the qualities and methods from a warrior
 */
public class Warrior extends Adventurer{

    /**
     * main constructor of the Warrior class
     * @param userName name of character
     * @param bodyStat body stat number
     * @param mindStat mind stat number
     * @param spiritStat spirit stat number
     * @param level level of the character
     * @param playername name of the player from the character
     * @param characterClass class of the character
     */
    public Warrior(String userName, int bodyStat, int mindStat, int spiritStat, int level, String playername, String characterClass) {
        super(userName, bodyStat, mindStat, spiritStat, level, playername, characterClass);
        setCharacterClass("Warrior");
    }

    /**
     * creates a warrior from a character class
     * @param character character to be a warrior
     */
    public Warrior(Character character) {
        super(character);
        setCharacterClass("Warrior");
    }

    /**
     * computes the preparation stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> preparationChar(ArrayList<Character> adventureCharacters) {
        setSpirit((getSpirit()) + 1);
        ArrayList<String> list = new ArrayList<>();
        list.add("Self-motivated");
        list.add("1");
        return list;
    }

    /**
     * computes the rest stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> restChar(ArrayList<Character> adventureCharacters) {
        int heal = getDice().rollDice(8) + getMind();
        if(getHitPoints() == getMaxHP()){
            heal = 0;
        }else{
            setHitPoints(Math.min(((getHitPoints()) + heal), getMaxHP()));
        }
        ArrayList<String> list = new ArrayList<>();
        list.add("Bandage time");
        list.add(Integer.toString(heal));
        return list;
    }

    /**
     * creates and computes an action which is some attack or healing action made by a monster or a character
     * @param adventureCharacters arrayList with the characters of the adventure
     * @param participantAdventure participant that gets affected by the action
     * @param encounterMonsters monsters from the encounter adventure
     * @return an action class containing all the information about the action done
     */
    @Override
    public Action createAction(ArrayList<Character> adventureCharacters, ParticipantsAdventure participantAdventure, ArrayList<ParticipantsAdventure> encounterMonsters) {
        String name = "Improved sword slash";
        int typeDice = getDice().rollDice(10);
        int type;
        if(typeDice == 1){
            type = 0;
        }else if(typeDice == 10){
            type = 2;
        }else{
            type = 1;
        }
        ArrayList<ParticipantsAdventure> target = new ArrayList<>();
        target.add(participantAdventure);
        int damage = improvedSwordSlash(type, target);
        return new Action(target, name, damage, type);
    }

    /**
     * computes the attack of the adventurer improved sword slash
     * @param target monster to hit
     * @param type type of attack (fail, normal or critical)
     * @return damage taken by the character
     */
    public int improvedSwordSlash(int type, ArrayList<ParticipantsAdventure> target) {
        int damage = 0;
        if(type == 1){
            if(target.get(0).isBoss() && getDamageType().equals(target.get(0).getDamageType())){
                damage = getDice().rollDice(10) + getBody()/2;
            }else{
                damage = getDice().rollDice(10) + getBody();
            }
        }
        if(type == 2){
            if(target.get(0).isBoss() && getDamageType().equals(target.get(0).getDamageType())){
                damage = getDice().rollDice(10) + getBody();
            }else{
                damage = getDice().rollDice(10) + getBody()*2;
            }
        }
        target.get(0).setHitPoints(target.get(0).getHitPoints() - damage);
        return damage;
    }

    /**
     * computes the dealing damage action from the monster to the characters
     * @param damage amount of damage taken by the attack
     * @param damageType tyoe of the damage
     * @return the actual damage taken by the character
     */
    @Override
    public int dealAttack(int damage, String damageType){
        if(damageType.equals("Physical")){
            damage = damage/2;
        }
        setHitPoints(getHitPoints() - damage);
        return damage;
    }

}
