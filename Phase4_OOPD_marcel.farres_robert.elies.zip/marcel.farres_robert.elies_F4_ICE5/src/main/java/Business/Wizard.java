package Business;

import java.util.ArrayList;

/**
 * This class has all the qualities and methods from a Wizard
 */
public class Wizard extends Character{
    private int shield;
    private Dice dice;

    /**
     * main constructor of the Wizard class
     * @param userName name of character
     * @param bodyStat body stat number
     * @param mindStat mind stat number
     * @param spiritStat spirit stat number
     * @param level level of the character
     * @param playername name of the player from the character
     * @param characterClass class of the character
     */
    public Wizard(String userName, int bodyStat, int mindStat, int spiritStat, int level, String playername, String characterClass) {
        super(userName, playername, bodyStat, mindStat, spiritStat, level, characterClass);
        dice = new Dice();
        this.shield = 0;
        setCharacterClass("Wizard");
    }

    /**
     * @return the shield value from the wizard
     */
    @Override
    public int getShield() {
        return shield;
    }

    /**
     * sets a value to the shield of the wizard
     * @param shield number of hp of the shield
     */
    public void setShield(int shield) {
        this.shield = shield;
    }

    /**
     * computes the preparation stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> preparationChar(ArrayList<Character> adventureCharacters) {
        ArrayList<String> list = new ArrayList<>();
        int valueShield = (dice.rollDice(6) + getMind()) * getLevel();
        setShield(valueShield);
        list.add("Mage shield");
        list.add(Integer.toString(valueShield));
        return list;
    }

    /**
     * computes the rest stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> restChar(ArrayList<Character> adventureCharacters) {
        ArrayList<String> list = new ArrayList<>();
        list.add(" is reading a book.");
        list.add("0");
        return list;
    }

    /**
     * creates and computes an action which is some attack or healing action made by a monster or a character
     * @param adventureCharacters arrayList with the characters of the adventure
     * @param participantAdventure participant that gets affected by the action
     * @param encounterMonsters monsters from the encounter adventure
     * @return an action class containing all the information about the action done
     */
    @Override
    public Action createAction(ArrayList<Character> adventureCharacters, ParticipantsAdventure participantAdventure, ArrayList<ParticipantsAdventure> encounterMonsters) {
        int typeDice = dice.rollDice(10);
        int type;
        if(typeDice == 1){
            type = 0;
        }else if(typeDice == 10){
            type = 2;
        }else{
            type = 1;
        }
        int counter = 0;
        int i;
        for(i = 0; i < encounterMonsters.size(); i++){
            if(encounterMonsters.get(i).getHitPoints() > 0){
                counter++;
            }
        }
        if(counter > 2){
            String name = "Fireball";
            ArrayList<ParticipantsAdventure> target = new ArrayList<>(encounterMonsters);
            int damage = fireball(type, target);
            return new Action(target, name, damage, type);
        }else{
            String name = "Arcane missile";
            ArrayList<ParticipantsAdventure> target = new ArrayList<>();
            int pos = 0;
            for(i = 0; i < encounterMonsters.size(); i++){
                if(encounterMonsters.get(i).getHitPoints() > encounterMonsters.get(pos).getHitPoints()){
                    pos = i;
                }
            }
            target.add(encounterMonsters.get(pos));
            int damage = arcaneMissile(type, target);
            return new Action(target, name, damage, type);
        }
    }

    /**
     * computes the attack of the wizard arcane missile
     * @param target monster to hit
     * @param type type of attack (fail, normal or critical)
     * @return damage taken by the character
     */
    public int arcaneMissile(int type, ArrayList<ParticipantsAdventure> target) {
        int damage = 0;
        if(type == 1){
            if(target.get(0).isBoss() && getDamageType().equals(target.get(0).getDamageType())){
                damage = (dice.rollDice(6) + getMind())/2;
            }else{
                damage = dice.rollDice(6) + getMind();
            }
        }
        if(type == 2){
            if(target.get(0).isBoss() && getDamageType().equals(target.get(0).getDamageType())){
                damage = dice.rollDice(6) + getMind();
            }else{
                damage = (dice.rollDice(6) + getMind())*2;
            }
        }
        target.get(0).setHitPoints(target.get(0).getHitPoints() - damage);
        return damage;
    }

    /**
     * computes the attack of the wizard fireball
     * @param target monster to hit
     * @param type type of attack (fail, normal or critical)
     * @return damage taken by the character
     */
    public int fireball(int type, ArrayList<ParticipantsAdventure> target) {
        int damage = dice.rollDice(4) + getMind();
        if(type == 1){
            for (ParticipantsAdventure participantsAdventure : target) {
                if (target.get(0).isBoss() && getDamageType().equals(target.get(0).getDamageType())) {
                    damage = (damage) / 2;
                }
                participantsAdventure.setHitPoints(participantsAdventure.getHitPoints() - damage);
                damage = dice.rollDice(4) + getMind();
            }
        }
        if(type == 2){
            for (ParticipantsAdventure participantsAdventure : target) {
                if (!(target.get(0).isBoss()) && !(getDamageType().equals(target.get(0).getDamageType()))) {
                    damage = (damage) * 2;
                }
                participantsAdventure.setHitPoints(participantsAdventure.getHitPoints() - damage);
                damage = dice.rollDice(4) + getMind();
            }
        }
        if(type == 0){
            damage = 0;
        }
        return damage;
    }

    /**
     * computes the dealing damage action from the monster to the characters
     * @param damage amount of damage taken by the attack
     * @param damageType tyoe of the damage
     * @return the actual damage taken by the character
     */
    @Override
    public int dealAttack(int damage, String damageType){
        if(damageType.equals("Magical")){
            damage = damage - getLevel();
        }
        int copydamage = damage;
        while((getShield() == 0) && copydamage > 0){
            setShield(getShield() - 1);
            copydamage--;
        }
        setHitPoints(getHitPoints() - copydamage);
        return damage;
    }
}
