package Business;

import Persistence.MonsterApi;
import Persistence.MonsterDAO;
import Persistence.MonsterJson;
import java.util.ArrayList;

/**
 * Manages all the methods related with monsters (computing and persistence)
 */
public class MonsterManager {
    private final MonsterDAO monsterDAO;
//constructor

    /**
     * creates new Monster Persistence class depending on the input
     * @param typeOfData int chosen by the user that decides which type of persistence the game will have
     */
    public MonsterManager(int typeOfData){
        if(typeOfData == 1){
            monsterDAO = new MonsterJson();
        }else{
            monsterDAO = new MonsterApi();
        }
    }
//methods

    /**
     * method that tests that the monsters file opens correctly
     * @return true if the file opens correctly
     */
    public boolean beginPersistenceMonster(){
        return monsterDAO.openFileMonster();
    }

    /**
     * method that gets all the monsters from the file into an ArrayList
     * @return ArrayList with all the Monsters
     */
    public ArrayList<Monster> getAll(){
        return monsterDAO.readFileMonster();
    }

    /**
     * method that gets just one monster from the file
     * @param indexMonster number that is the position of the monster in the ArrayList
     * @return the monster
     */
    public Monster getMonster(int indexMonster){
        return monsterDAO.readFileMonster().get(indexMonster - 1);
    }
}
