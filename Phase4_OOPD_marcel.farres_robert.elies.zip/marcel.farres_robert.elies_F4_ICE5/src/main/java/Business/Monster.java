package Business;

import java.util.ArrayList;

/**
 * class with all the monsters attributes and its methods and constructor
 */
public class Monster implements ParticipantsAdventure{
    private String name;
    private String challenge;
    private int experience;
    private int hitPoints;
    private int initiative;
    private String damageDice;
    private String damageType;
    private Dice dice;
//constructor

    /**
     * Main constructor of the monster class
     * @param name name of the monster
     * @param challenge rank of monster (from minion to boss)
     * @param experience level of the monster
     * @param hitPoints life points of the monster
     * @param initiative value of starting fighting
     * @param damageDice number of damage dice used
     * @param damageType type of damage
     */
    public Monster(String name, String challenge, int experience, int hitPoints, int initiative, String damageDice, String damageType) {
        this.name = name;
        this.challenge = challenge;
        this.experience = experience;
        this.hitPoints = hitPoints;
        this.initiative = initiative;
        this.damageDice = damageDice;
        this.damageType = damageType;
        dice = new Dice();
    }
//methods

    /**
     * @return String containing the name of the Monster
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * @return the challenge type of the Monster
     */
    public String getChallenge() {
        return challenge;
    }

    /**
     * @return the experience of the Monster
     */
    public int getExperience() {
        return experience;
    }

    /**
     * @return the HP of the monster
     */
    @Override
    public int getHitPoints() {
        return hitPoints;
    }

    /**
     * inserts new quantity of HP
     * @param hitPoints new quantity of HP
     */
    @Override
    public void setHitPoints(int hitPoints) {
        this.hitPoints = hitPoints;
    }

    /**
     * checks if a Monster is Boss
     * @return true is the Monster is a Boss Class
     */
    @Override
    public boolean isBoss() {
        return getClass().equals(Boss.class);
    }

    /**
     * computes the preparation stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> preparationChar(ArrayList<Character> adventureCharacters) {
        //this method is created only for Character's preparation Stage, that is why here on Monsters we do not do anything
        return null;
    }

    /**
     * @return the shield value for the Wizards
     */
    @Override
    public int getShield() {
        return 0;
    }

    /**
     * computes the rest stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> restChar(ArrayList<Character> adventureCharacters) {
        //this method is created only for Character's rest Stage, that is why here on Monsters we do not do anything
        return null;
    }

    /**
     * creates and computes an action which is some attack or healing action made by a monster or a character
     * @param adventureCharacters arrayList with the characters of the adventure
     * @param participantAdventure participant that gets affected by the action
     * @param encounterMonsters monsters from the encounter adventure
     * @return an action class containing all the information about the action done
     */
    @Override
    public Action createAction(ArrayList<Character> adventureCharacters, ParticipantsAdventure participantAdventure, ArrayList<ParticipantsAdventure> encounterMonsters) {
        dice = new Dice();
        String name = "MonsterAttack";
        String numberString = getDamageDice().substring(1);
        int numDice = Integer.parseInt(numberString);
        int damage = dice.rollDice(numDice);
        int typeDice = dice.rollDice(10);
        int type;
        if(typeDice == 1){
            type = 0;
            damage = 0;
        }else if(typeDice == 10){
            type = 2;
            damage = damage * 2;
        }else{
            type = 1;
        }
        ArrayList<ParticipantsAdventure> target = new ArrayList<>();
        target.add(participantAdventure);
        damage = target.get(0).dealAttack(damage, getDamageType());
        return new Action(target, name, damage, type);
    }

    /**
     * computes the dealing damage action from the monster to the characters
     * @param damage amount of damage taken by the attack
     * @param damageType tyoe of the damage
     * @return the actual damage taken by the character
     */
    @Override
    public int dealAttack(int damage, String damageType) {
        return 0;
        //method for deal damage to the Characters, the Monsters get their damage dealt directly on the create Action
        //from the Characters
    }

    /**
     * @return the max HealthPoints from a Character
     */
    @Override
    public int getMaxHP() {
        return 0;
    }

    /**
     * @return initiative of the Monster
     */
    public int getInitiative() {
        return initiative;
    }

    /**
     * @return the dice class for the extended classes
     */
    public Dice getDice() {
        return dice;
    }

    /**
     * @return the damage quantity of the dice of the monster
     */
    @Override
    public String getDamageDice() {
        return damageDice;
    }

    /**
     * @return the type of damage of the monster
     */
    @Override
    public String getDamageType() {
        return damageType;
    }

    /**
     * @return true if the Participant is a Character (false if is a monster)
     */
    @Override
    public boolean isCharacter(){
        return false;
    }

    /**
     * @return BodyStat of the Character
     */
    @Override
    public int getBody() {
        return 0;
    }
}
