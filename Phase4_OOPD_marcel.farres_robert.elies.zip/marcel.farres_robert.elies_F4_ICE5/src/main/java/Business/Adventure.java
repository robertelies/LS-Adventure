package Business;

import java.util.ArrayList;

/**
 * class with all attributes, methods and constructors of the adventure
 */
public class Adventure {
    private String name;
    private int numEncounters;
    private ArrayList<Encounter> allEncounters;
//constructors

    /**
     * constructor from scratch of an adventure
     * @param name name of adventure
     * @param numEncounters number of encounters
     * @param allEncounters arraylist with all the encounters
     */
    public Adventure(String name, int numEncounters, ArrayList<Encounter> allEncounters) {
        this.name = name;
        this.numEncounters = numEncounters;
        this.allEncounters = allEncounters;
    }

    /**
     * this constructor gets an adventure and saves it on the program
     * @param adventure adventure
     */
    public Adventure(Adventure adventure) {
        this.name = adventure.name;
        this.numEncounters = adventure.numEncounters;
        this.allEncounters = adventure.allEncounters;
    }

    /**
     * this constructor creates an adventure with the name of the adventure and the encounter arrayList
     * @param name name of the Adventure
     * @param allEncounters arrayList of encounters
     */
    public Adventure(String name, ArrayList<Encounter> allEncounters) {
        this.name = name;
        this.allEncounters = allEncounters;
        this.numEncounters = allEncounters.size();
    }
//methods

    /**
     * @return name of the adventure
     */
    public String getName() {
        return name;
    }

    /**
     * @return the number of encounters
     */
    public int getNumEncounters() {
        return numEncounters;
    }

    /**
     * @return an ArrayList with all the encounters
     */
    public ArrayList<Encounter> getAllEncounters() {
        return allEncounters;
    }
}
