package Business;

import java.util.ArrayList;

/**
 * This interface has methods that affect both characters and monsters
 */
public interface ParticipantsAdventure {
    /**
     * @return name of the participant
     */
    String getName();

    /**
     * @return HitPoints of the Participant
     */
    int getHitPoints();

    /**
     * @return true if the Participant is a Character (false if is a monster)
     */
    boolean isCharacter();

    /**
     * @return BodyStat of the Character
     */
    int getBody();

    /**
     * @return the damageDice of the Monster
     */
    String getDamageDice();

    /**
     * @return the damage type of the monster
     */
    String getDamageType();

    /**
     * sets a new quantity of HP
     * @param hitPoints new quantity of HP
     */
    void setHitPoints(int hitPoints);

    /**
     * checks if a Monster is Boss
     * @return true is the Monster is a Boss Class
     */
    boolean isBoss();

    /**
     * computes the preparation stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    ArrayList<String> preparationChar(ArrayList<Character> adventureCharacters);

    /**
     * @return the shield value for the Wizards
     */
    int getShield();

    /**
     * computes the rest stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    ArrayList<String> restChar(ArrayList<Character> adventureCharacters);

    /**
     * creates and computes an action which is some attack or healing action made by a monster or a character
     * @param adventureCharacters arrayList with the characters of the adventure
     * @param participantsAdventure participant that gets affected by the action
     * @param encounterMonsters monsters from the encounter adventure
     * @return an action class containing all the information about the action done
     */
    Action createAction(ArrayList<Character> adventureCharacters, ParticipantsAdventure participantsAdventure, ArrayList<ParticipantsAdventure> encounterMonsters);

    /**
     * computes the dealing damage action from the monster to the characters
     * @param damage amount of damage taken by the attack
     * @param damageType tyoe of the damage
     * @return the actual damage taken by the character
     */
    int dealAttack(int damage, String damageType);

    /**
     * @return the max HealthPoints from a Character
     */
    int getMaxHP();
}
