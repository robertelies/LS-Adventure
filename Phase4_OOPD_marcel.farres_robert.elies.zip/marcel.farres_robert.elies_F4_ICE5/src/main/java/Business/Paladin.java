package Business;

import java.util.ArrayList;

/**
 * This class has all the qualities and methods from the paladin
 */
public class Paladin extends Cleric{

    /**
     * main constructor of the Paladin class
     * @param userName name of character
     * @param bodyStat body stat number
     * @param mindStat mind stat number
     * @param spiritStat spirit stat number
     * @param level level of the character
     * @param playername name of the player from the character
     * @param characterClass class of the character
     */
    public Paladin(String userName, int bodyStat, int mindStat, int spiritStat, int level, String playername, String characterClass) {
        super(userName, bodyStat, mindStat, spiritStat, level, playername, characterClass);
        setCharacterClass("Paladin");
    }

    /**
     * creates a Paladin from a character class
     * @param character character to be a Paladin
     */
    public Paladin(Character character) {
        super(character);
        setCharacterClass("Paladin");
    }

    /**
     * computes the preparation stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> preparationChar(ArrayList<Character> adventureCharacters) {
        ArrayList<String> list = new ArrayList<>();
        int numDice = getDice().rollDice(3);
        for (Character d: adventureCharacters){
            d.setMind((d.getMind()) + numDice);
        }
        list.add("Blessing of good luck");
        list.add(Integer.toString(numDice));
        return list;
    }

    /**
     * computes the rest stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> restChar(ArrayList<Character> adventureCharacters) {
        int heal = getDice().rollDice(10) + getMind();
        for(Character c: adventureCharacters){
            if(c.getHitPoints() != c.getMaxHP()){
                c.setHitPoints(Math.min(((c.getHitPoints()) + heal), c.getMaxHP()));
            }
        }
        ArrayList<String> list = new ArrayList<>();
        list.add("Prayer of mass healing");
        list.add(Integer.toString(heal));
        StringBuilder names = new StringBuilder();
        int i;
        for(i = 0; i < adventureCharacters.size() - 1; i++){
            names.append(adventureCharacters.get(i).getName());
            if(i + 1 != adventureCharacters.size() - 1){
                names.append(", ");
            }
        }
        names.append("and ");
        names.append(adventureCharacters.get(i).getName());
        names.append(".");
        list.add(names.toString());
        return list;
    }

    /**
     * creates and computes an action which is some attack or healing action made by a monster or a character
     * @param adventureCharacters arrayList with the characters of the adventure
     * @param participantAdventure participant that gets affected by the action
     * @param encounterMonsters monsters from the encounter adventure
     * @return an action class containing all the information about the action done
     */
    @Override
    public Action createAction(ArrayList<Character> adventureCharacters, ParticipantsAdventure participantAdventure, ArrayList<ParticipantsAdventure> encounterMonsters) {
        boolean flag = false;
        int i;
        for(i = 0; i < adventureCharacters.size(); i++){
            if(adventureCharacters.get(i).getHitPoints() < adventureCharacters.get(i).getMaxHP()){
                flag = true;
                break;
            }
        }
        if(flag){
            String name = "Prayer of mass healing";
            ArrayList<ParticipantsAdventure> target = new ArrayList<>(adventureCharacters);
            int heal = prayerOfMassHealing(target);
            return new Action(target, name, heal);
        }else{
            String name = "Never on my watch";
            int typeDice = getDice().rollDice(10);
            int type;
            if(typeDice == 1){
                type = 0;
            }else if(typeDice == 10){
                type = 2;
            }else{
                type = 1;
            }
            ArrayList<ParticipantsAdventure> target = new ArrayList<>();
            target.add(participantAdventure);
            int damage = neverOnMyWatch(target, type);
            return new Action(target, name, damage, type);
        }
    }

    /**
     * computes the damage attack of the paladin never on my watch
     * @param target monster to hit
     * @param type type of attack (fail, normal or critical)
     * @return damage taken by the character
     */
    public int neverOnMyWatch(ArrayList<ParticipantsAdventure> target, int type) {
        int damage = 0;
        if(type == 1){
            if(target.get(0).isBoss() && getDamageType().equals(target.get(0).getDamageType())){
                damage = (getDice().rollDice(8) + getSpirit())/2;
            }else{
                damage = getDice().rollDice(8) + getSpirit();
            }
        }
        if(type == 2){
            if(target.get(0).isBoss() && getDamageType().equals(target.get(0).getDamageType())){
                damage = getDice().rollDice(8) + getSpirit();
            }else{
                damage = (getDice().rollDice(8) + getSpirit())*2;
            }
        }
        target.get(0).setHitPoints(target.get(0).getHitPoints() - damage);
        return damage;
    }

    /**
     * computes the healing attack of the paladin prayer of mass healing
     * @param target characters to heal
     * @return heal taken by the characters individually
     */
    public int prayerOfMassHealing(ArrayList<ParticipantsAdventure> target) {
        int heal = getDice().rollDice(10) + getMind();
        for (ParticipantsAdventure participantsAdventure : target) {
            participantsAdventure.setHitPoints(Math.min(((participantsAdventure.getHitPoints()) + heal), participantsAdventure.getMaxHP()));
        }
        return heal;
    }

    /**
     * computes the dealing damage action from the monster to the characters
     * @param damage amount of damage taken by the attack
     * @param damageType tyoe of the damage
     * @return the actual damage taken by the character
     */
    @Override
    public int dealAttack(int damage, String damageType){
        if(damageType.equals("Psychical")){
            damage = damage/2;
        }
        setHitPoints(getHitPoints() - damage);
        return damage;
    }
}
