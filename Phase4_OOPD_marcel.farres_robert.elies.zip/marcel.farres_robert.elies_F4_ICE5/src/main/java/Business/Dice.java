package Business;

import java.util.Random;

/**
 * This class does the dice roll everytime its method is called
 */
public class Dice {

    /**
     * sets up a random number from 1 to the number of sides of the dice
     * @param side number of sides of the dice
     * @return result (the random number from the dice)
     */
    public int rollDice(int side){
        Random rand = new Random();
        return (rand.nextInt(side) + 1);
    }
}
