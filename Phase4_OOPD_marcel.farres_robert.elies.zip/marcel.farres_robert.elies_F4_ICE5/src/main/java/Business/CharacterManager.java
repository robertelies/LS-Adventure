package Business;

import Persistence.*;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Manager class from all the character computations and persistence
 */
public class CharacterManager {
    private Dice dice;
    private final CharacterDAO characterDAO;
//constructor

    /**
     * creates new Character Persistence class depending on the input and dice class
     * @param typeOfData int chosen by the user that decides which type of persistence the game will have
     */
    public CharacterManager(int typeOfData){
        dice = new Dice();
        if(typeOfData == 1){
            characterDAO = new CharacterJson();
        }else{
            characterDAO = new CharacterApi();
        }
    }
//methods

    /**
     * checks that there is a number on the username
     * @param userName name of the user
     * @return true if there is a number on the name
     */
    public boolean checkUserName(String userName) {
        for(int i = 0; i < userName.length(); i++){
            if((userName.charAt(i) == '1') || (userName.charAt(i) == '2') || (userName.charAt(i) == '3') || (userName.charAt(i) == '4') || (userName.charAt(i) == '5') || (userName.charAt(i) == '6') || (userName.charAt(i) == '7') || (userName.charAt(i) == '8') || (userName.charAt(i) == '9') || (userName.charAt(i) == '0')){
                return true;
            }
        }
        return false;
    }

    /**
     * checks if the name is already used
     * @param userName name of the user
     * @return true if the name exists
     */
    public boolean checkUnique(String userName) {
        for(Character c: characterDAO.readFileCharacter()){
            if(userName.equals(c.getName())){
                return true;
            }
        }
        return false;
    }

    /**
     * changes the name into universal format
     * @param userName name of the user
     * @return name in univeral format
     */
    public String universalFormat(String userName) {
        String[] parts = userName.split(" ");
        StringBuilder camelCaseString = new StringBuilder();
        for (String part : parts){
            camelCaseString.append(' ').append(toProperCase(part));
        }
        String finalName = camelCaseString.toString();
        finalName = finalName.substring(1);
        return finalName;
    }

    /**
     * changes the cases of the word
     * @param s string to change
     * @return string with the correct casing
     */
    public String toProperCase(String s) {
        return s.substring(0, 1).toUpperCase() +
                s.substring(1).toLowerCase();
    }

    /**
     * checks that the level is between 1 and 10
     * @param level level to check
     * @return true if the level is not between 1 amd 10
     */
    public boolean checkLevel(int level) {
        return (level > 10) || (level < 1);
    }

    /**
     * rolls a dice with the desired number
     * @param num umber to roll the dice
     * @return number rolled by the dice
     */
    public int rollDiceStats(int num) {
        return dice.rollDice(num);
    }

    /**
     * computes the stats with the number the dice rolled
     * @param roll1 first roll
     * @param roll2 second roll
     * @return result of the stats
     */
    public int getStats(int roll1, int roll2) {
        if(roll1 + roll2 == 2){
            return -1;
        }
        if((roll1 + roll2 >= 3) && (roll1 + roll2 <= 5)){
            return 0;
        }
        if((roll1 + roll2 >= 6) && (roll1 + roll2 <= 9)){
            return 1;
        }
        if((roll1 + roll2 >= 10) && (roll1 + roll2 <= 11)){
            return 2;
        }else{
            return 3;
        }
    }

    /**
     * creates a new character
     * @param userName name of user
     * @param playerName name of player
     * @param level level of the character
     * @param bodyStat body stat of the character
     * @param mindStat mind stat of the character
     * @param spiritStat spirit stat of the character
     */
    public void createCharacter(String userName, String playerName, int level, int bodyStat, int mindStat, int spiritStat, String characterClass) {
        if(characterClass.equals("Adventurer")){
            Character c = new Adventurer(userName, bodyStat, mindStat, spiritStat, level, playerName, characterClass);
            if((level > 3) && (level < 8)){
                c = new Warrior(c);
            }
            if(level > 7){
                c = new Champion(c);
            }
            characterDAO.updateCharacters(c);
        }
        if(characterClass.equals("Cleric")){
            Character c = new Cleric(userName, bodyStat, mindStat, spiritStat, level, playerName, characterClass);
            if(level > 4){
                c = new Paladin(c);
            }
            characterDAO.updateCharacters(c);
        }
        if(characterClass.equals("Wizard")){
            Character c = new Wizard(userName, bodyStat, mindStat, spiritStat, level, playerName, characterClass);
            characterDAO.updateCharacters(c);
        }
    }

    /**
     * searches character with similar value from the filter
     * @param filter string filter to search
     * @return ArrayList with all the finds
     */
    public ArrayList<Character> listCharacters(String filter) {
        boolean exist = false;
        if(Objects.equals(filter, "")){
            return characterDAO.readFileCharacter();
        }else{
            ArrayList<Character> charactersCopy = new ArrayList<>();
            for(Character c: characterDAO.readFileCharacter()){
                if(c.getName().toLowerCase().contains(filter.toLowerCase())){
                    charactersCopy.add(c);
                    exist = true;
                }
            }
            if(exist){
                return charactersCopy;
            }else{
                return null;
            }
        }
    }

    /**
     * deletes a character from the json file
     * @param name name of the character to delete
     */
    public void deleteCharacter(String name) {
        int i = 0;
        for(Character c: characterDAO.readFileCharacter()){
            if(c.getName().equals(name)){
                characterDAO.removeCharacter(c, i);
            }
            i++;
        }
    }

    /**
     * @return size of the character file
     */
    public int getNumOfCharacters() {
        return characterDAO.readFileCharacter().size();
    }

    /**
     * @return ArrayList with all the charcters
     */
    public ArrayList<Character> getAllCharacters() {
        return characterDAO.readFileCharacter();
    }

    /**
     * when a character get to a certain level, this method evolves the character if its necessary
     * @param c Character to evolve
     * @param type which type of evolution will happen
     *             adventurer -> warrior, warrior -> champion, cleric -> paladin
     * @return the character evolved
     */
    public Character evolveCharacter(Character c, int type) {
        int index = 0;
        for(int i = 0; i < getAllCharacters().size(); i++){
            if(c.getName().equals(getAllCharacters().get(i).getName())){
                index = i;
                break;
            }
        }
        if(type == 1){
            Warrior newCharacter = new Warrior(c);
            characterDAO.removeCharacter(c, index);
            characterDAO.updateCharacters(newCharacter);
            return newCharacter;
        }else {
            if(type == 2){
                Champion newCharacter = new Champion(c);
                characterDAO.removeCharacter(c, index);
                characterDAO.updateCharacters(newCharacter);
                return newCharacter;
            }else{
                Paladin newCharacter = new Paladin(c);
                characterDAO.removeCharacter(c, index);
                characterDAO.updateCharacters(newCharacter);
                return newCharacter;
            }
        }
    }
}
