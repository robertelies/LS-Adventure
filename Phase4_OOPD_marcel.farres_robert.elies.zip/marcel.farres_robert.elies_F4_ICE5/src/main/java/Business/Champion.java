package Business;

import java.util.ArrayList;

/**
 * This class has all the qualities and methods from a Champion
 */
public class Champion extends Warrior{

    /**
     * main constructor of the Champion class
     * @param userName name of character
     * @param bodyStat body stat number
     * @param mindStat mind stat number
     * @param spiritStat spirit stat number
     * @param level level of the character
     * @param playername name of the player from the character
     * @param characterClass class of the character
     */
    public Champion(String userName, int bodyStat, int mindStat, int spiritStat, int level, String playername, String characterClass) {
        super(userName, bodyStat, mindStat, spiritStat, level, playername, characterClass);
        setHitPoints(getHitPoints() + (getBody() * getLevel()));
        setMaxHP(getHitPoints() + (getBody() * getLevel()));
        setCharacterClass("Champion");
    }

    /**
     * creates a Champion from a character class
     * @param character character to be a champion
     */
    public Champion(Character character) {
        super(character);
        setHitPoints(getHitPoints() + (getBody() * getLevel()));
        setMaxHP(getHitPoints() + (getBody() * getLevel()));
        setCharacterClass("Champion");
    }

    /**
     * computes the preparation stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> preparationChar(ArrayList<Character> adventureCharacters) {
        ArrayList<String> list = new ArrayList<>();
        for (Character d: adventureCharacters){
            d.setSpirit((d.getSpirit()) + 1);
        }
        list.add("Motivational speech");
        list.add("1");
        return list;
    }

    /**
     * computes the rest stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> restChar(ArrayList<Character> adventureCharacters) {
        setHitPoints(getMaxHP());
        ArrayList<String> list = new ArrayList<>();
        list.add("Improved bandage time");
        list.add("0");
        return list;
    }

    /**
     * creates and computes an action which is some attack or healing action made by a monster or a character
     * @param adventureCharacters arrayList with the characters of the adventure
     * @param participantAdventure participant that gets affected by the action
     * @param encounterMonsters monsters from the encounter adventure
     * @return an action class containing all the information about the action done
     */
    @Override
    public Action createAction(ArrayList<Character> adventureCharacters, ParticipantsAdventure participantAdventure, ArrayList<ParticipantsAdventure> encounterMonsters) {
        String name = "Improved sword slash";
        int typeDice = getDice().rollDice(10);
        int type;
        if(typeDice == 1){
            type = 0;
        }else if(typeDice == 10){
            type = 2;
        }else{
            type = 1;
        }
        ArrayList<ParticipantsAdventure> target = new ArrayList<>();
        target.add(participantAdventure);
        int damage = improvedSwordSlash(type, target);
        return new Action(target, name, damage, type);
    }

    /**
     * computes the dealing damage action from the monster to the characters
     * @param damage amount of damage taken by the attack
     * @param damageType tyoe of the damage
     * @return the actual damage taken by the character
     */
    @Override
    public int dealAttack(int damage, String damageType){
        if(damageType.equals("Physical")){
            damage = damage/2;
        }
        setHitPoints(getHitPoints() - damage);
        return damage;
    }
}
