package Business;

import java.util.ArrayList;

/**
 * Class containing the different aspects of a boss compared with a normal monster
 */
public class Boss extends Monster{

    /**
     * Main constructor of the monster class
     *
     * @param name       name of the monster
     * @param challenge  rank of monster (from minion to boss)
     * @param experience level of the monster
     * @param hitPoints  life points of the monster
     * @param initiative value of starting fighting
     * @param damageDice number of damage dice used
     * @param damageType type of damage
     */
    public Boss(String name, String challenge, int experience, int hitPoints, int initiative, String damageDice, String damageType) {
        super(name, challenge, experience, hitPoints, initiative, damageDice, damageType);
    }

    /**
     * checks if a Monster is Boss
     * @return true is the Monster is a Boss Class
     */
    @Override
    public boolean isBoss(){
        return true;
    }

    /**
     * creates and computes an action which is some attack or healing action made by a monster or a character
     * @param adventureCharacters arrayList with the characters of the adventure
     * @param participantAdventure participant that gets affected by the action
     * @param encounterMonsters monsters from the encounter adventure
     * @return an action class containing all the information about the action done
     */
    @Override
    public Action createAction(ArrayList<Character> adventureCharacters, ParticipantsAdventure participantAdventure, ArrayList<ParticipantsAdventure> encounterMonsters) {
        String name = "BossAttack";
        int numDice;
        if(getDamageDice().length() == 2){
            numDice = getDamageDice().charAt(1);
        }else{
            numDice = (getDamageDice().charAt(1) * 10) + (getDamageDice().charAt(2));
        }
        int damage = getDice().rollDice(numDice);
        int typeDice = getDice().rollDice(10);
        int type;
        if(typeDice == 1){
            type = 0;
            damage = 0;
        }else if(typeDice == 10){
            type = 2;
            damage = damage * 2;
        }else{
            type = 1;
        }
        ArrayList<ParticipantsAdventure> target = new ArrayList<>(adventureCharacters);
        for(Character c: adventureCharacters){
            int buffer = c.dealAttack(damage, getDamageType());
        }
        return new Action(target, name, damage, type);
    }

}
