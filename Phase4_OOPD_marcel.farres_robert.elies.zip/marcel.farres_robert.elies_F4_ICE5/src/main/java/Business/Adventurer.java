package Business;

import java.util.ArrayList;

/**
 * This class has all the qualities and methods from an adventurer
 */
public class Adventurer extends Character{
    private Dice dice;

    /**
     * main constructor of the Adventurer class
     * @param userName name of character
     * @param bodyStat body stat number
     * @param mindStat mind stat number
     * @param spiritStat spirit stat number
     * @param level level of the character
     * @param playername name of the player from the character
     * @param characterClass class of the character
     */
    public Adventurer(String userName, int bodyStat, int mindStat, int spiritStat, int level, String playername, String characterClass) {
        super(userName, playername, bodyStat, mindStat, spiritStat, level, characterClass);
        dice = new Dice();
        setCharacterClass("Adventurer");
    }

    /**
     * creates an adventurer from a character class
     * @param character character to be an adventurer
     */
    public Adventurer(Character character) {
        super(character);
        dice = new Dice();
        setCharacterClass("Adventurer");
    }

    /**
     * @return the dice class for the extended classes
     */
    public Dice getDice() {
        return dice;
    }

    /**
     * computes the preparation stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> preparationChar(ArrayList<Character> adventureCharacters) {
        setSpirit((getSpirit()) + 1);
        ArrayList<String> list = new ArrayList<>();
        list.add("Self-motivated");
        list.add("1");
        return list;
    }

    /**
     * @return the shield value for the Wizards
     */
    @Override
    public int getShield() {
        return 0;
    }

    /**
     * computes the rest stage for a character
     * @param adventureCharacters arrayList with all the characters that could be involved
     * @return ArrayList of Strings that contain the action to be done and the amount of change
     */
    @Override
    public ArrayList<String> restChar(ArrayList<Character> adventureCharacters) {
        int heal = dice.rollDice(8) + getMind();
        if(getHitPoints() == getMaxHP()){
            heal = 0;
        }else{
            setHitPoints(Math.min(((getHitPoints()) + heal), getMaxHP()));
        }
        ArrayList<String> list = new ArrayList<>();
        list.add("Bandage time");
        list.add(Integer.toString(heal));
        return list;
    }

    /**
     * creates and computes an action which is some attack or healing action made by a monster or a character
     * @param adventureCharacters arrayList with the characters of the adventure
     * @param participantAdventure participant that gets affected by the action
     * @param encounterMonsters monsters from the encounter adventure
     * @return an action class containing all the information about the action done
     */
    @Override
    public Action createAction(ArrayList<Character> adventureCharacters, ParticipantsAdventure participantAdventure, ArrayList<ParticipantsAdventure> encounterMonsters) {
        String name = "Sword slash";
        int typeDice = dice.rollDice(10);
        int type;
        if(typeDice == 1){
            type = 0;
        }else if(typeDice == 10){
            type = 2;
        }else{
            type = 1;
        }
        ArrayList<ParticipantsAdventure> target = new ArrayList<>();
        target.add(participantAdventure);
        int damage = swordSlash(target, type);
        return new Action(target, name, damage, type);
    }

    /**
     * computes the attack of the adventurer sword slash
     * @param target monster to hit
     * @param type type of attack (fail, normal or critical)
     * @return damage taken by the character
     */
    public int swordSlash(ArrayList<ParticipantsAdventure> target, int type) {
        int damage = 0;
        if(type == 1){
            if(target.get(0).isBoss() && getDamageType().equals(target.get(0).getDamageType())){
                damage = (dice.rollDice(6) + getBody())/2;
            }else{
                damage = dice.rollDice(6) + getBody();
            }
        }
        if(type == 2){
            if(target.get(0).isBoss() && getDamageType().equals(target.get(0).getDamageType())){
                damage = dice.rollDice(6) + getBody();
            }else{
                damage = (dice.rollDice(6) + getBody())*2;
            }
        }
        target.get(0).setHitPoints(target.get(0).getHitPoints() - damage);
        return damage;
    }

    /**
     * computes the dealing damage action from the monster to the characters
     * @param damage amount of damage taken by the attack
     * @param damageType tyoe of the damage
     * @return the actual damage taken by the character
     */
    @Override
    public int dealAttack(int damage, String damageType){
        setHitPoints(getHitPoints() - damage);
        return damage;
    }
}
