package Business;

/**
 * class with all atributes, constructors and methods related to character
 */
public abstract class Character implements ParticipantsAdventure{
    private String name;
    private String player;
    private int body;
    private int mind;
    private int spirit;
    private String characterClass;
    private int xp;
    private int level;
    private int hitPoints;
    private String damageType;
    private int maxHP;
//constructor

    /**
     * creates a character from scratch
     * @param userName name of character
     * @param bodyStat body ability from the character
     * @param mindStat mind ability of the character
     * @param spiritStat spirit ability from the character
     * @param level level of the character
     * @param playername name of the player's character
     */
    public Character(String userName, String playername, int bodyStat, int mindStat, int spiritStat, int level, String characterClass) {
        this.name = userName;
        this.player = playername;
        this.body = bodyStat;
        this.mind = mindStat;
        this.spirit = spiritStat;
        this.level = level;
        this.xp = (level - 1)*100;
        this.characterClass = characterClass;
        this.hitPoints = (10 + bodyStat)*level;
        this.maxHP = (10 + bodyStat)*level;
        if(characterClass.equals("Adventurer") || characterClass.equals("Warrior") || characterClass.equals("Champion")){
            this.damageType = "Physical";
        }
        if(characterClass.equals("Wizard")){
            this.damageType = "Magical";
        }
        if(characterClass.equals("Cleric") || characterClass.equals("Paladin")){
            this.damageType = "Psychical";
        }
    }

    /**
     * gets a character and saves his stats on the program
     * @param character character
     */
    public Character(Character character) {
        this.name = character.getName();
        this.player = character.getPlayer();
        this.body = character.getBody();
        this.mind = character.getMind();
        this.spirit = character.getSpirit();
        this.characterClass = character.getCharacterClass();
        this.level = character.getLevel();
        this.xp = character.getXp();
        this.hitPoints = (10 + character.getBody())*character.getLevel();
        this.maxHP = (10 + character.getBody())*character.getLevel();
        this.damageType = character.getDamageType();
    }
//methods

    /**
     * @return name of the Character
     */
    @Override
    public String getName() {
        return name;
    }

    /**
     * @return Body stat of the character
     */
    @Override
    public int getBody() {
        return body;
    }

    /**
     * @return Mind stat of the character
     */
    public int getMind() {
        return mind;
    }

    /**
     * @return Spirit stat of the Character
     */
    public int getSpirit() {
        return spirit;
    }

    /**
     * inserts new spirit value
     * @param spirit value to insert
     */
    public void setSpirit(int spirit) {
        this.spirit = spirit;
    }

    /**
     * @return class of the character
     */
    public String getCharacterClass() {
        return characterClass;
    }

    /**
     * @return the xp of the character
     */
    public int getXp() {
        return xp;
    }

    /**
     * inserts a new xp value to the character
     * @param xp value to insert
     */
    public void setXp(int xp) {
        this.xp = xp;
    }

    /**
     * @return the player name
     */
    public String getPlayer() {
        return player;
    }

    /**
     * @return the level of the character
     */
    public int getLevel() {
        return level;
    }

    /**
     * inserts new level value to the character
     * @param level new value to insert
     */
    public void setLevel(int level) {
        this.level = level;
    }

    /**
     * @return HitPoints of the character
     */
    @Override
    public int getHitPoints() {
        return hitPoints;
    }

    /**
     * inserts new HP value
     * @param hitPoints new quantity of HP
     */
    @Override
    public void setHitPoints(int hitPoints) {
        this.hitPoints = hitPoints;
    }

    /**
     * sets new Health Points when the character levels up
     */
    public void redoHealthPoints() {
        int newHP = (10 + getBody())*getLevel();
        setHitPoints(newHP);
    }

    /**
     * checks if a Monster is Boss
     * @return true is the Monster is a Boss Class
     */
    @Override
    public boolean isBoss() {
        return false;
    }

    /**
     * sets the Class of the character
     * @param characterClass class type of the character
     */
    public void setCharacterClass(String characterClass) {
        this.characterClass = characterClass;
    }

    /**
     * sets desired the mind parameter on the Character
     * @param mind Mind attribute of the Character
     */
    public void setMind(int mind) {
        this.mind = mind;
    }

    /**
     * @return the maximum HealthPoints of a Character
     */
    @Override
    public int getMaxHP() {
        return maxHP;
    }

    /**
     * sets a value to the maxHP attribute
     * @param maxHP maximum health points possible
     */
    public void setMaxHP(int maxHP) {
        this.maxHP = maxHP;
    }

    /**
     * @return the type of damage of the character
     */
    @Override
    public String getDamageType() {
        return damageType;
    }

    /**
     * @return true if the Participant is a Character (false if is a monster)
     */
    @Override
    public boolean isCharacter(){
        return true;
    }

    /**
     * @return the damageDice of the Monster
     */
    @Override
    public String getDamageDice() {
        return null;
    }


}
