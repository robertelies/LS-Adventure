package Business;

import java.util.ArrayList;

/**
 * this class defines the characteristic of an action (damage or healing)
 */
public class Action {
    private ArrayList<ParticipantsAdventure> targets;
    private String nameAction;
    private int damage;
    private int damageType;
    private int heal;

    /**
     * contructor of the damage action
     * @param targets participants that will take the damage
     * @param nameAction name of the action
     * @param damage damage to take
     * @param damageType type of damage (fail, normal or critical)
     */
    public Action(ArrayList<ParticipantsAdventure> targets, String nameAction, int damage, int damageType){
        this.targets = targets;
        this.nameAction = nameAction;
        this.damage = damage;
        this.damageType = damageType;
        this.heal = -1;
    }

    /**
     * constructor of the healing action
     * @param targets targetis that will get cure
     * @param nameAction name of the action
     * @param heal HP to heal
     */
    public Action(ArrayList<ParticipantsAdventure> targets, String nameAction, int heal){
        this.targets = targets;
        this.nameAction = nameAction;
        this.damage = -1;
        this.damageType = -1;
        this.heal = heal;
    }

    /**
     * @return targets affected by the action
     */
    public ArrayList<ParticipantsAdventure> getTargets() {
        return targets;
    }

    /**
     * @return name of the action
     */
    public String getNameAction() {
        return nameAction;
    }

    /**
     * @return damage of the action
     */
    public int getDamage() {
        return damage;
    }

    /**
     * sets damage points
     * @param damage points to take to the participant
     */
    public void setDamage(int damage) {
        this.damage = damage;
    }

    /**
     * @return type of damage (fail, critical or normal)
     */
    public int getDamageType() {
        return damageType;
    }

    /**
     * sets a damage type number (0-2)
     * @param damageType type of damage (fail, normal or critical)
     */
    public void setDamageType(int damageType) {
        this.damageType = damageType;
    }

    /**
     * @return HP points to heal
     */
    public int getHeal() {
        return heal;
    }

    /**
     * sets the points to heal
     * @param heal HP points to heal
     */
    public void setHeal(int heal) {
        this.heal = heal;
    }
}
