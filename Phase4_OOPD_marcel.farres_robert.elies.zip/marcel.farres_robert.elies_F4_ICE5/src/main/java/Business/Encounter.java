package Business;

import java.util.ArrayList;

/**
 * class from the encounter
 */
public class Encounter {
    private ArrayList<Monster> monsters;
    private ArrayList<Integer> numberMonsters;
//constructor

    /**
     * main constructor of an encounter
     * @param monsters arraylist of the monsters from the encounter
     * @param numberMonsters number of each monster type of the encounter
     */
    public Encounter(ArrayList<Monster> monsters, ArrayList<Integer> numberMonsters) {
        this.monsters = monsters;
        this.numberMonsters = numberMonsters;
    }
//methods

    /**
     * @return ArrayList of the monsters of the encounter
     */
    public ArrayList<Monster> getMonsters() {
        return monsters;
    }

    /**
     * @return ArrayList of the number of each monster of the encounter
     */
    public ArrayList<Integer> getNumberMonsters() {
        return numberMonsters;
    }
}
