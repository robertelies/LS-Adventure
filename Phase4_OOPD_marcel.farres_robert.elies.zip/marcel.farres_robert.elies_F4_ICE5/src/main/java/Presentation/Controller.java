package Presentation;

import Business.*;
import Business.Character;
import java.io.IOException;
import java.util.ArrayList;

/**
 * This class controls the inputs that come from the interface and calls the managers for them to compute this information
 * it is divided into the main method and the following programs that each one executes a different task of the program
 */
public class Controller {
    private UiManager uinterface;
    private AdventureManager adventureM;
    private MonsterManager monsterM;
    private CharacterManager characterM;

    /**
     * constructor that creates new UiManager, and the business package managers
     */
    public Controller(){
        uinterface = new UiManager();
    }

    /**
     * method that runs the program
     */
    public void run() throws IOException {
        int typeOfData = uinterface.firstMsg();
        boolean apiOk = false;
        if(typeOfData == 2){
            monsterM = new MonsterManager(typeOfData);
            characterM = new CharacterManager(typeOfData);
            adventureM = new AdventureManager(typeOfData);
            boolean downloadMonsterApi = monsterM.beginPersistenceMonster();
            if(!downloadMonsterApi){
                uinterface.msgDownloadMonster(3);
            }else{
                apiOk = true;
                uinterface.msgDownloadMonster(2);
            }
        }
        if(typeOfData == 1 || !apiOk){
            typeOfData = 1;
            monsterM = new MonsterManager(typeOfData);
            characterM = new CharacterManager(typeOfData);
            adventureM = new AdventureManager(typeOfData);
            boolean downloadMonsterJson = monsterM.beginPersistenceMonster();
            if(!downloadMonsterJson){
                uinterface.msgDownloadMonster(1);
                return;
            }else{
                uinterface.msgDownloadMonster(2);
            }
        }
        int mainOption;
        do{
            uinterface.tavernMsg(1, null, 0);
            int num = characterM.getNumOfCharacters();
            mainOption = uinterface.printMenu(num);
            switch (mainOption) {
                case 1:
                    characterCreation();
                    break;
                case 2:
                    characterList();
                    break;
                case 3:
                    adventureCreation();
                    break;
                case 4:
                    if(num < 3){
                        uinterface.errorPlay();
                        break;
                    }else{
                        adventurePlay();
                        break;
                    }
                case 5:
                    exit();
                    break;
                default:
                    uinterface.defaultErrormsg();
            }
        }while (mainOption != 5);
    }

    /**
     * Runs the adventures
     */
    public void adventurePlay() {
        ArrayList<Character> allCharacters = (ArrayList<Character>) characterM.getAllCharacters().clone();
        uinterface.tavernMsg(6, null, 0);
        int numAdventure = uinterface.listAllAdventures(adventureM.getAllAdventuresName());
        adventureM.setCurrentAdventure(numAdventure - 1);
        uinterface.tavernMsg(14, adventureM.getCurrentAdventureName(), 0);
        int numCharacters = uinterface.getCharacters();
        if(numCharacters < 3 || numCharacters > 5){
            uinterface.defaultErrormsg();
        }else{
            uinterface.tavernMsg(15, null, numCharacters);
            for(int i = 1; i <= numCharacters; i++){
                int positionCharacter = uinterface.pickCharacters(numCharacters, allCharacters, adventureM.getAdventureCharactersName(), (i -1));
                positionCharacter = positionCharacter - 1;
                adventureM.setCharacter(positionCharacter, allCharacters);
                allCharacters.remove(positionCharacter);
            }
            uinterface.printWholeSquad(adventureM.getAdventureCharactersName(), numCharacters);
            uinterface.tavernMsg(16, adventureM.getCurrentAdventureName(), 0);
            for(int i = 0; i < adventureM.getNumberOfEncounters(); i++){
                uinterface.infoEncounter(adventureM.getEncounter(i), (i+1));
                uinterface.preparationStageIntro();
                for(int k = 0; k < adventureM.getAdventureCharacters().size(); k++){
                    uinterface.preparationStage(adventureM.getAdventureCharactersName().get(k), adventureM.preparationStage(adventureM.getAdventureCharacters().get(k)));
                }
                adventureM.createParticipants(i);
                uinterface.printRollInitiative(adventureM.getParticipants(), adventureM.getOrder());
                uinterface.combatStage();
                adventureM.setOriginalHitpoints();
                int round = 1;
                while(!(adventureM.deadMonsters(i)) && !(adventureM.battleLost())){
                    uinterface.printPartyStats(round, adventureM.getAdventureCharacters());
                    int attack = 0;
                    while(attack < adventureM.getParticipants().size()){
                        if(adventureM.alive(attack)){
                            ArrayList<ParticipantsAdventure> versus = adventureM.whoAttack(attack);
                            if(versus.get(0).isCharacter()){
                                uinterface.printAttackCharacter(adventureM.newAction(versus), versus.get(0));
                                if(adventureM.isKill(versus)){
                                    uinterface.killConfirm(versus);
                                }
                            }else{
                                uinterface.printAttackMonster(adventureM.newAction(versus), versus.get(0));
                            }
                        }
                        attack++;
                        if((adventureM.deadMonsters(i)) || (adventureM.battleLost())){
                            attack = adventureM.getParticipants().size();
                        }
                    }
                    uinterface.roundFinished(round);
                    round++;
                }
                if(adventureM.deadMonsters(i)){
                    uinterface.enemiesDefeated();
                    int addXp = adventureM.computeXp(i);
                    uinterface.restStageExperience(adventureM.getAdventureCharacters(), addXp);
                    adventureM.uploadXp(addXp);
                    for(int k = 0; k < adventureM.getAdventureCharacters().size(); k++){
                        uinterface.restStageHealing(adventureM.getAdventureCharacters().get(k), adventureM.uploadHp(adventureM.getAdventureCharacters().get(k)));
                    }
                    adventureM.resetInitiative();
                }
                if(adventureM.battleLost()){
                    uinterface.tavernMsg(17, null, 0);
                    allCharacters.clear();
                    adventureM.reset();
                    return;
                }
            }
            uinterface.endOfBattle(adventureM.getCurrentAdventureName());
            allCharacters.clear();
            adventureM.reset();
        }
    }

    /**
     * creates an adventure
     */
    public void adventureCreation() {
        uinterface.tavernMsg(5, null, 0);
        String adventureName = uinterface.getAdventureName();
        boolean error = adventureM.checkUnique(adventureName);
        if(error){
            uinterface.defaultErrormsg();
        }else{
            uinterface.tavernMsg(12, adventureName, 0);
            int errorNum = 0;
            int numEncounters = uinterface.getEncounters();
            while(errorNum < 3){
                if((numEncounters < 1) || (numEncounters > 4)){
                    errorNum++;
                    uinterface.defaultErrormsg();
                    numEncounters = uinterface.getEncounters();
                }else{
                    break;
                }
            }
            if(errorNum < 3){
                int i = 1;
                int option;
                uinterface.tavernMsg(13, null, numEncounters);
                ArrayList<Monster> encounterMonsters = new ArrayList<>();
                ArrayList<Integer> numMonsters = new ArrayList<>();
                ArrayList<Encounter> creatingEncounters = new ArrayList<>();
                while(i <= numEncounters){
                    do{
                        option = uinterface.manageEncounter(i, encounterMonsters, numEncounters, numMonsters);
                        if(option == 1){
                            int k = 0;
                            boolean found = false;
                            int indexMonster = uinterface.displayMonsters(monsterM.getAll());
                            Monster newMonster = monsterM.getMonster(indexMonster);
                            Integer amount = uinterface.getAmountMonsters(newMonster);
                            if((newMonster.getChallenge().equals("Boss")) && (amount > 1)){
                                uinterface.defaultErrormsg();
                            }else{
                                while(k < encounterMonsters.size()){
                                    if(encounterMonsters.get(k).getName().equals(newMonster.getName())){
                                        found = true;
                                        break;
                                    }
                                    k++;
                                }
                                if(found){
                                    if(newMonster.getChallenge().equals("Boss")){
                                        boolean repeated = adventureM.getRepeatedMonster(encounterMonsters, newMonster.getName());
                                        if((adventureM.getBoss(encounterMonsters)) && repeated){
                                            uinterface.defaultErrormsg();
                                        }
                                    }else{
                                        amount = amount + numMonsters.get(k);
                                        numMonsters.set(k, amount);
                                    }
                                }else{
                                    if((adventureM.getBoss(encounterMonsters)) && (newMonster.getChallenge().equals("Boss"))){
                                        uinterface.defaultErrormsg();
                                    }else{
                                        encounterMonsters.add(newMonster);
                                        numMonsters.add(amount);
                                    }
                                }
                            }
                        }
                        if(option == 2){
                            int numDelete = uinterface.deleteMonsters();
                            uinterface.deleteMessage(encounterMonsters, numMonsters, numDelete);
                            adventureM.deleteMonsters(encounterMonsters, numMonsters, numDelete);
                        }
                        if(option == 3){
                            i++;
                            creatingEncounters = adventureM.createEncounter(encounterMonsters, numMonsters);
                            encounterMonsters = new ArrayList<>();
                            numMonsters = new ArrayList<>();
                        }
                    }while(option != 3);
                }
                adventureM.createAdventure(adventureName, numEncounters, creatingEncounters);
            }
        }
    }

    /**
     * searches and manages characters
     */
    public void characterList() {
        uinterface.tavernMsg(4, null, 0);
        String filter = uinterface.scanName();
        ArrayList<Character> list = characterM.listCharacters(filter);
        if(list == null){
            uinterface.defaultErrormsg();
        }else{
            int numCharacter = uinterface.printCharacters(list);
            if(numCharacter > 0){
                while(numCharacter >= list.size()){
                    uinterface.errorList(list.size()-1);
                    numCharacter = uinterface.printCharacters(list);
                }
                uinterface.tavernMsg(10, list.get(numCharacter).getName(), 0);
                String compareName = uinterface.printOneCharacter(list.get(numCharacter));
                while((!(compareName.equals(""))) && (!(compareName.equals(list.get(numCharacter).getName())))){
                    compareName = uinterface.errorNameAskAgain(list.get(numCharacter).getName());
                }
                if(compareName.equals(list.get(numCharacter).getName())){
                    characterM.deleteCharacter(list.get(numCharacter).getName());
                    uinterface.tavernMsg(11, null, 0);
                    uinterface.deletionMsg(list.get(numCharacter).getName());
                }
            }
        }
    }

    /**
     * creates character
     */
    public void characterCreation() {
        uinterface.tavernMsg(3, null, 0);
        String userName = uinterface.userName();
        boolean error = characterM.checkUserName(userName);
        if(error){
            uinterface.defaultErrormsg();
        }else{
            error = characterM.checkUnique(userName);
            if(error){
                uinterface.defaultErrormsg();
            }else{
                userName = characterM.universalFormat(userName);
                uinterface.tavernMsg(7, userName, 0);
                String playerName = uinterface.playerName();
                uinterface.tavernMsg(8, null, 0);
                int level = uinterface.characterLevel();
                error = characterM.checkLevel(level);
                if(error){
                    uinterface.defaultErrormsg();
                }else{
                    uinterface.tavernMsg(9, null, level);
                    int bodyRoll1 = characterM.rollDiceStats(6);
                    int bodyRoll2 = characterM.rollDiceStats(6);
                    int mindRoll1 = characterM.rollDiceStats(6);
                    int mindRoll2 = characterM.rollDiceStats(6);
                    int spiritRoll1 = characterM.rollDiceStats(6);
                    int spiritRoll2 = characterM.rollDiceStats(6);
                    int bodyStat = characterM.getStats(bodyRoll1, bodyRoll2);
                    int mindStat = characterM.getStats(mindRoll1, mindRoll2);
                    int spiritStat = characterM.getStats(spiritRoll1, spiritRoll2);
                    uinterface.printStats(bodyRoll1, bodyRoll2, mindRoll1, mindRoll2, spiritRoll1, spiritRoll2, bodyStat, mindStat, spiritStat);
                    uinterface.tavernMsg(18, null, 0);
                    String characterClass = uinterface.getCharacterClass();
                    if(characterClass.equals("Adventurer") || characterClass.equals("Cleric") || characterClass.equals("Wizard")){
                        uinterface.tavernMsg(19, characterClass, 0);
                        characterM.createCharacter(userName, playerName, level, bodyStat, mindStat, spiritStat, characterClass);
                        uinterface.characterCreated(userName);
                    }else{
                        uinterface.defaultErrormsg();
                    }
                }
            }
        }
    }

    /**
     * ends program
     */
    public void exit() {
        uinterface.tavernMsg(2, null, 0);
    }
}
