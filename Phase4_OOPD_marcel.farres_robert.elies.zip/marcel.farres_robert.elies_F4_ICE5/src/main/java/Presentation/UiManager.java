package Presentation;

import Business.*;
import Business.Character;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * This class manages the interface for the user. It prints messages and scans information that we need from the user
 */
public class UiManager {

    /**
     * Prints the first message of the program
     * @return number representing the option
     */
    public int firstMsg() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n\nWelcome to Simple LSRPG.\n\nDo you want to use your local or cloud data?\n\t1) Local data\n\t2) Cloud data");
        System.out.println("\n\t-> Answer: ");
        return scanner.nextInt();
    }

    /**
     * Prints if the monsters file was correctly accessed or not
     * @param i is 1 if the opening of the file gave an error
     */
    public void msgDownloadMonster(int i)  {
        if(i == 1){
            System.out.println("Loading data...");
            System.out.println("Error: The monsters.json file can’t be accessed.\n\n");
        }
        if(i == 2){
            System.out.println("Loading data...");
            System.out.println("Data was successfully loaded.\n\n");
        }
        if(i == 3){
            System.out.println("Loading data...\nCouldn't connect to the remote server.\nReverting to local data.\n\n");
        }
    }

    /**
     * This function prints all the messages from the Tavern Keeper
     * @param i is the number of the message to print
     * @param string contains a String to be printed (depends on the message)
     * @param num contains a number to be printed (depends on the message)
     */
    public void tavernMsg(int i, String string, int num) {
        if(i == 1){
            System.out.println("The tavern keeper looks at you and says: \n'Welcome adventurer! How can I help you?'\n");
        }
        if(i == 2){
            System.out.println("\nTavern keeper: 'Are you leaving already? See you soon, adventurer.'");
        }
        if(i == 3){
            System.out.println("\nTavern keeper: 'Oh, so you are new to this land.' \n'What's your name?'\n");
        }
        if(i == 4){
            System.out.println("\nTavern keeper: 'Lads! They want to see you!' \n'Who piques your interest?'\n");
        }
        if(i == 5){
            System.out.println("\nTavern keeper: 'Planning an adventure? Good luck with that!'\n");
        }
        if(i == 6){
            System.out.println("\nTavern keeper: 'So, you are looking to go on an adventure?' \n'Where do you fancy going?'\n");
        }
        if(i == 7){
            System.out.println("\nTavern keeper: 'Hello, "+ string +", be welcome.' \n'And now, if I may break the fourth wall, who is your Player?'\n");
        }
        if(i == 8){
            System.out.println("\nTavern keeper: 'I see, I see...' \n'Now, are you an experienced adventurer?'\n");
        }
        if(i == 9){
            System.out.println("\nTavern keeper: 'Oh, so you are level "+ num +"!' \n'Great, let me get a closer look at you...'\n");
        }
        if(i == 10){
            System.out.println("\nTavern keeper: 'Hey "+ string +" get here; the boss wants to see you!'\n");
        }
        if(i == 11){
            System.out.println("\nTavern keeper: 'I'm sorry kiddo, but you have to leave.'\n");
        }
        if(i == 12){
            System.out.println("\nTavern keeper: 'You plan to undertake "+ string +", really?' \n'How long will that take?'\n");
        }
        if(i == 13){
            System.out.println("\nTavern keeper: '"+ num +" encounters? That is too much for me...'");
        }
        if(i == 14){
            System.out.println("\nTavern keeper: '"+ string +" it is!' \n'And how many people shall join you?'\n");
        }
        if(i == 15){
            System.out.println("\nTavern keeper: 'Great, "+ num +" it is.' \n'Who among these lads shall join you?'");
        }
        if(i == 16){
            System.out.println("\nTavern keeper: 'Great, good luck on your adventure lads!'\n\nThe '"+ string +"' will start soon...");
        }
        if(i == 17){
            System.out.println("\nTavern keeper: 'Lad, wake up. Yes, your party fell unconscious.' \n'Don't worry, you are safe back at the Tavern.'\n");
        }
        if(i == 18){
            System.out.println("\nTavern keeper: 'Looking good!'\n'And, lastly, ?'\n");
        }
        if(i == 19){
            System.out.println("\nTavern keeper: 'Any decent party needs one of those.'\n'I guess that means you're a " + string + " by now, nice!'\n");
        }
    }

    /**
     * Prints the main menu of the program
     * @param num is the number of characters (if the number is less than 3 the option 4 is disabled)
     * @return the number of option to run
     */
    public int printMenu(int num) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\t1) Character creation");
        System.out.println("\t2) List characters");
        System.out.println("\t3) Create an adventure");
        if(num < 3){
            System.out.println("\t4) Start an adventure (disabled: create 3 characters first)");
        }else{
            System.out.println("\t4) Start an adventure");
        }
        System.out.println("\t5) Exit\n");
        System.out.println("Your answer: ");
        return scanner.nextInt();
    }

    /**
     * Prints a default error message
     */
    public void defaultErrormsg() {
        System.out.println("\nERROR THE INPUT WAS INCORRECT\n");
    }

    /**
     * Asks the user the name of the User
     * @return name of the User
     */
    public String userName() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-> Enter your name: ");
        return scanner.nextLine();
    }

    /**
     * Asks the user the name of the Player
     * @return name of thr Player
     */
    public String playerName() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-> Enter the player's name: ");
        return scanner.nextLine();
    }

    /**
     * Asks the user for the level of the character
     * @return level of the character
     */
    public int characterLevel() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-> Enter the character's level [1..10]: ");
        return scanner.nextInt();
    }

    /**
     * Prints the statistics randomly created for the Body, Mind and Spirit
     * @param bodyRoll1 the first roll for the Body statistic
     * @param bodyRoll2 the second roll for the Body statistic
     * @param mindRoll1 the first roll for the Mind statistic
     * @param mindRoll2 the second roll for the Mind statistic
     * @param spiritRoll1 the first roll for the Spirit statistic
     * @param spiritRoll2 the second roll for the Spirit statistic
     * @param bodyStat Body final statistic
     * @param mindStat Mind final statistic
     * @param spiritStat Spirit final statistic
     */
    public void printStats(int bodyRoll1, int bodyRoll2, int mindRoll1, int mindRoll2, int spiritRoll1, int spiritRoll2, int bodyStat, int mindStat, int spiritStat) {
        System.out.println("Generating your stats...\n");
        System.out.println("Body:   You rolled "+ (bodyRoll1 + bodyRoll2) +" ("+ bodyRoll1 +" and "+ bodyRoll2 +").");
        System.out.println("Mind:   You rolled "+ (mindRoll1 + mindRoll2) +" ("+ mindRoll1 +" and "+ mindRoll2 +").");
        System.out.println("Spirit: You rolled "+ (spiritRoll1 + spiritRoll2) +" ("+ spiritRoll1 +" and "+ spiritRoll2 +").\n");
        System.out.println("Your stats are:");
        if(bodyStat < 0){
            System.out.println(" - Body: "+ bodyStat);
        }else{
            System.out.println(" - Body: +"+ bodyStat);
        }
        if(mindStat < 0){
            System.out.println(" - Mind: "+ mindStat);
        }else{
            System.out.println(" - Mind: +"+ mindStat);
        }
        if(spiritStat < 0){
            System.out.println(" - Spirit: "+ spiritStat);
        }else{
            System.out.println(" - Spirit: +"+ spiritStat);
        }
    }

    /**
     * Asks the user for the name of the Player to filter
     * @return the name of the player
     */
    public String scanName() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-> Enter the name of the Player to filter: ");
        return scanner.nextLine();
    }

    /**
     * Prints all the characters that match the search and asks the User to pick
     * @param list all the Characters that match the String from the previous method
     * @return int that is the number of the player selected by the user
     */
    public int printCharacters(ArrayList<Character> list) {
        Scanner scanner = new Scanner(System.in);
        int i;
        System.out.println("\nYou watch as some adventurers get up from their chairs and approach you.\n");
        for(i = 0; i < list.size(); i++){
            System.out.println("\t"+ (i+1) +". "+ list.get(i).getName());
        }
        System.out.println("\n\t0. Back\n");
        System.out.println("Who would you like to meet [1.." + i +"]: ");
        return scanner.nextInt();
    }

    /**
     * Prints error when a number range parameter was wrong
     * @param i max value to introduce
     */
    public void errorList(int i) {
        System.out.println("\nERROR!! YOU SHOULD WRITE A NUMBER FROM [1.."+ i +"]\n");
    }

    /**
     * Prints the whole attributes of a single character
     * @param character the Character to print
     * @return a String where the user says if he wants to delete or not the character
     */
    public String printOneCharacter(Character character) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("* Name:   "+ character.getName());
        System.out.println("* Player: "+ character.getPlayer());
        System.out.println("* Class:  "+ character.getCharacterClass());
        System.out.println("* Level:  "+ character.getLevel());
        System.out.println("* XP:     "+ character.getXp());
        if(character.getBody() < 0){
            System.out.println("* Body:   "+ character.getBody());
        }else{
            System.out.println("* Body:   +"+ character.getBody());
        }
        if(character.getMind() < 0){
            System.out.println("* Mind:   "+ character.getMind());
        }else{
            System.out.println("* Mind:   +"+ character.getMind());
        }
        if(character.getSpirit() < 0){
            System.out.println("* Spirit: "+ character.getSpirit());
        }else{
            System.out.println("* Spirit: +"+ character.getSpirit());
        }
        System.out.println("\n[Enter name to delete, or press enter to cancel]");
        System.out.println("Do you want to delete "+ character.getName() +"? ");
        return scanner.nextLine();
    }

    /**
     * Prints an error message of a name written wrong and asks again if the user wants to delete it
     * @param name name of the character to delete
     * @return the response of the user
     */
    public String errorNameAskAgain(String name) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nERROR YOU WROTE WRONG THE NAME");
        System.out.println("\n[Enter name to delete, or press enter to cancel]");
        System.out.println("Do you want to delete "+ name +"? ");
        return scanner.nextLine();
    }

    /**
     * Prints the confirmation of a character deleted
     * @param name name of the Character deleted
     */
    public void deletionMsg(String name) {
        System.out.println("Character "+ name +" left the Guild.");
    }

    /**
     * Asks the suer for the name of the Adventure
     * @return the name of the adventure
     */
    public String getAdventureName() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-> Name your adventure: ");
        return scanner.nextLine();
    }

    /**
     * Asks the user for the number of encounters of the adventure
     * @return the number of encounters
     */
    public int getEncounters() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-> How many encounters do you want [1..4]: ");
        return scanner.nextInt();
    }

    /**
     * Prints the monsters in an encounter and asks the user for the next functionality (what to do with the encounter)
     * @param i number of encounter
     * @param encounterMonsters Monsters from the encounter
     * @param numEncounters total number of encounters
     * @param numMonsters number of monsters (of the same monster)
     * @return the next functionality to do with the encounter (add other monster, delete monster, continue)
     */
    public int manageEncounter(int i, ArrayList<Monster> encounterMonsters, int numEncounters, ArrayList<Integer> numMonsters) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n\n* Encounter "+ i +" / "+ numEncounters);
        System.out.println("* Monsters in encounter");
        if(encounterMonsters.size() == 0){
            System.out.println("  # Empty\n");
        }else{
            for(int j = 0; j < encounterMonsters.size(); j++){
                System.out.println("  "+ (j+1) +". "+ encounterMonsters.get(j).getName() +" (x"+ numMonsters.get(j) +")");
            }
        }
        System.out.println("\n1. Add monster");
        System.out.println("2. Remove monster");
        System.out.println("3. Continue\n");
        System.out.println("-> Enter an option [1..3]: ");
        return scanner.nextInt();
    }

    /**
     *Prints all the Monsters from the monster file and asks the user to choose one of them for the encounter
     * @param allMonsters ArrayList containing all the monsters
     * @return the number of the monster chosen by the user
     */
    public int displayMonsters(ArrayList<Monster> allMonsters) {
        Scanner scanner = new Scanner(System.in);
        for(int j = 0; j < allMonsters.size(); j++){
            System.out.println("  "+ (j+1) +". "+ allMonsters.get(j).getName() +" ("+ allMonsters.get(j).getChallenge() +")");
        }
        System.out.println("\n-> Choose a monster to add [1.."+ allMonsters.size() +"]:");
        return scanner.nextInt();
    }

    /**
     * Asks the user how many monsters of the one selected before wants
     * @param newMonster Monster selected by the user
     * @return the number of monsters to be added
     */
    public Integer getAmountMonsters(Monster newMonster) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-> How many "+ newMonster.getName() +"(s) do you want to add: ");
        return scanner.nextInt();
    }

    /**
     * Asks the user which monster from the ones selected from the encounter to delete
     * @return the number of the monster to delete
     */
    public int deleteMonsters() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-> Which monster do you want to delete: ");
        return scanner.nextInt();
    }

    /**
     * Prints that the monster was successfully deleted
     * @param encounterMonsters ArrayList of Monsters from the encounter
     * @param numMonsters ArrayList of number of monsters from the encounter
     * @param numDelete position in the arraylist to delete
     */
    public void deleteMessage(ArrayList<Monster> encounterMonsters, ArrayList<Integer> numMonsters, int numDelete) {
        System.out.println(numMonsters.get(numDelete - 1) +" "+ encounterMonsters.get(numDelete - 1).getName() +" were removed from the encounter.");
    }

    /**
     * Prints an error message saying that at least 3 characters should be created
     */
    public void errorPlay() {
        System.out.println("ERROR YOU HAVE TO CREATE AT LEAST 3 CHARACTERS TO START AN ADVENTURE");
    }

    /**
     * Prints all the adventures and asks the user to choose one
     * @param allAdventures ArrayList of all the adventures name
     * @return number of position of the adventure in the ArrayList
     */
    public int listAllAdventures(ArrayList<String> allAdventures) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Available adventures:");
        for(int i = 0; i < allAdventures.size(); i++){
            System.out.println("  "+ (i + 1) +". "+ allAdventures.get(i));
        }
        System.out.println("\n-> Choose an adventure: ");
        return scanner.nextInt();
    }

    /**
     * Asks the user for the number of characters in the adventure
     * @return the number of characters in the adventure
     */
    public int getCharacters() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-> Choose a number of characters [3..5]: ");
        return scanner.nextInt();
    }

    /**
     * Prints the party and lets the user to pick the characters to fill up the party for the adventure
     * @param numCharacters total number of characters
     * @param allCharacters ArrayList of all the characters
     * @param adventureCharacters ArrayList of the characters in the adventure (party)
     * @param i nnumber of the character choosing
     * @return position in the allCharacters arrayList (to pick the character)
     */
    public int pickCharacters(int numCharacters, ArrayList<Character> allCharacters, ArrayList<String> adventureCharacters, int i) {
        Scanner scanner = new Scanner(System.in);
        int j;
        System.out.println("\n\n");
        System.out.println("------------------------------");
        System.out.println("Your party ("+ i +" / "+ numCharacters +"):");
        if(adventureCharacters.size() == 0) {
            for (j = 0; j < numCharacters; j++){
                System.out.println((j + 1) + ". Empty");
            }
        }else{
            for (j = 0; j < numCharacters; j++){
                if(j < i){
                    System.out.println((j + 1) +". "+ adventureCharacters.get(j));
                }else{
                    System.out.println((j + 1) + ". Empty");
                }
            }
        }
        j = 1;
        System.out.println("------------------------------");
        System.out.println("Available characters:");
        for(Character c: allCharacters){
            System.out.println(j +". "+ c.getName());
            j++;
        }
        System.out.println("\n-> Choose character "+ (i + 1) +" in your party: ");
        return scanner.nextInt();
    }

    /**
     * Prints the whole character party for the adventure
     * @param adventureCharacters ArrayList with the characters for the adventure
     * @param numCharacters total number of characters
     */
    public void printWholeSquad(ArrayList<String> adventureCharacters, int numCharacters) {
        System.out.println("------------------------------");
        System.out.println("Your party ("+ numCharacters +" / "+ numCharacters +"):");
        for (int j = 0; j < numCharacters; j++){
            System.out.println((j + 1) +". "+ adventureCharacters.get(j));
        }
        System.out.println("------------------------------");
    }

    /**
     * Prints a message aying that the adventure was completed
     * @param currentAdventureName name of the adventure
     */
    public void endOfBattle(String currentAdventureName) {
        System.out.println("\n\nCongratulations, your party completed '"+ currentAdventureName +"'");
    }

    /**
     * Prints the preparation stage for one character
     * @param charName name of the Character taking the preparation Stage
     * @param prepList ArrayList with the name of the preparation action and the value of it
     */
    public void preparationStage(String charName, ArrayList<String> prepList) {
        if(prepList.get(0).equals("Self-motivated")){
            System.out.println(charName + " uses "+ prepList.get(0) +". Their Spirit increases in +1.");
        }else{
            if(prepList.get(0).equals("Motivational speech")){
                System.out.println(charName + " uses "+ prepList.get(0) +". Everyone’s Spirit increases in +1.");
            }else{
                if(prepList.get(0).equals("Prayer of good luck")){
                    System.out.println(charName + " uses "+ prepList.get(0) +". Everyone’s Mind increases in +1.");
                }else{
                    if(prepList.get(0).equals("Blessing of good luck")){
                        System.out.println(charName + " uses "+ prepList.get(0) +". Everyone’s Mind increases in +"+ prepList.get(1) +".");
                    }else{
                        System.out.println(charName + " uses "+ prepList.get(0) +". Shield recharges to "+ prepList.get(1) +".");
                    }
                }
            }
        }
    }

    /**
     * Prints the combat stage banner
     */
    public void combatStage() {
        System.out.println("--------------------");
        System.out.println("*** Combat stage ***");
        System.out.println("--------------------");
    }

    /**
     * Prints the main information about the encounter (monsters and number of encounter)
     * @param encounter Encounter taking part
     * @param i number of encounter
     */
    public void infoEncounter(Encounter encounter, int i) {
        System.out.println("\n---------------------");
        System.out.println("Starting Encounter "+ i +":");
        for(int j = 1; j <= encounter.getMonsters().size(); j++){
            System.out.println("  - "+ encounter.getNumberMonsters().get(j - 1) +"x "+ encounter.getMonsters().get(j - 1).getName());
        }
    }

    /**
     * Prints the rolling initiative
     * @param participants ArrayList with the participants of the adventure sorted in the rolling initiative way
     * @param order ArrayList of number with the result of the dices for each participant
     */
    public void printRollInitiative(ArrayList<ParticipantsAdventure> participants, ArrayList<Integer> order) {
        System.out.println("\nRolling initiative...");
        for(int j = 0; j < participants.size(); j++){
            System.out.println("  - "+ order.get(j) +" "+ participants.get(j).getName());
        }
        System.out.println("\n");
    }

    /**
     * Print the Party stats (hp and name)
     * @param round number of round
     * @param characters array of all the characters in the adventure
     */
    public void printPartyStats(int round, ArrayList<Character> characters) {
        System.out.println("Round "+ round +":");
        System.out.println("Party:");
        for(int i = 0; i < characters.size(); i++){
            if(characters.get(i).getHitPoints() < 1){
                System.out.println("  - "+ characters.get(i).getName() +" 0 / "+ characters.get(i).getMaxHP() +" hit points");
            }else{
                if(characters.get(i).getCharacterClass().equals("Wizard")){
                    System.out.println("  - "+ characters.get(i).getName() +" "+ characters.get(i).getHitPoints() +" / "+ characters.get(i).getMaxHP() +" hit points (Shield: "+ characters.get(i).getShield() +")");
                }else{
                    System.out.println("  - "+ characters.get(i).getName() +" "+ characters.get(i).getHitPoints() +" / "+ characters.get(i).getMaxHP() +" hit points");
                }
            }
        }
    }

    /**
     * Prints the end of the round
     * @param round number of round
     */
    public void roundFinished(int round) {
        System.out.println("\nEnd of round "+ round +".");
    }

    /**
     * Prints that all the enemies are defeated
     */
    public void enemiesDefeated() {
        System.out.println("All enemies are defeated.");
    }

    /**
     * Prints the first part of the rest stage
     * @param adventureCharacters ArrayList of the adventure characters
     * @param addXp the number of Xp to add
     */
    public void restStageExperience(ArrayList<Character> adventureCharacters, int addXp) {
        System.out.println("\n------------------------");
        System.out.println("*** Short rest stage ***");
        System.out.println("------------------------");
        for(Character c: adventureCharacters){
            if(c.getHitPoints() >= 1){
                if((((c.getXp() + addXp)/100) != (c.getLevel() - 1)) && (c.getLevel() != 10)){
                    System.out.println(c.getName() + " gains "+ addXp +" xp. "+ c.getName() +" levels up. They are now lvl "+ (c.getLevel() + 1) +"!");
                    if (c.getCharacterClass().equals("Adventurer") && c.getLevel() == 4) {
                        System.out.println(c.getName() +" evolves to Warrior!");
                    }
                    if (c.getCharacterClass().equals("Warrior") && c.getLevel() == 8) {
                        System.out.println(c.getName() +" evolves to Champion!");
                    }
                    if (c.getCharacterClass().equals("Cleric") && c.getLevel() == 5) {
                        System.out.println(c.getName() +" evolves to Paladin!");
                    }
                }else{
                    System.out.println(c.getName() + " gains "+ addXp +" xp. ");
                }
            }else{
                System.out.println(c.getName() + "is unconscious.");
            }
        }
        System.out.println("\n");
    }

    /**
     * Prints the main combat stage for the character
     * @param action class containing all the info from the attack/healing action taken
     * @param role the Participant that produces the attack (the one that attacks)
     */
    public void printAttackCharacter(Action action, ParticipantsAdventure role) {
        System.out.println("\n");
        if(action.getDamage() > -1){
            if(action.getNameAction().equals("Fireball")){
                StringBuilder names = new StringBuilder();
                int i;
                for(i = 0; i < action.getTargets().size() - 1; i++){
                    names.append(action.getTargets().get(i).getName());
                    if(i + 1 != action.getTargets().size() - 1){
                        names.append(", ");
                    }
                }
                names.append(" and ");
                names.append(action.getTargets().get(i).getName());
                System.out.println(role.getName() +" attacks "+ names +" with "+ action.getNameAction() +".");
            }else{
                System.out.println(role.getName() +" attacks "+ action.getTargets().get(0).getName() +" with "+ action.getNameAction() +".");
            }
            if(action.getDamageType() == 1){
                System.out.println("Hits and deals "+ action.getDamage() +" "+ role.getDamageType() +" damage.");
            }
            if(action.getDamageType() == 0){
                System.out.println("Fails and deals 0 "+ role.getDamageType() +" damage.");
            }
            if(action.getDamageType() == 2){
                System.out.println("Critical hit and deals "+ action.getDamage() +" "+ role.getDamageType() +" damage.");
            }
        }else{
            if(action.getNameAction().equals("Prayer of mass healing")){
                StringBuilder names = new StringBuilder();
                int i;
                for(i = 0; i < action.getTargets().size() - 1; i++){
                    names.append(action.getTargets().get(i).getName());
                    if(i + 1 != action.getTargets().size() - 1){
                        names.append(", ");
                    }
                }
                names.append(" and ");
                names.append(action.getTargets().get(i).getName());
                System.out.println(role.getName() +" uses Prayer of mass healing. Heals "+ action.getHeal() +" hit points to "+ names +".");
            }else{
                System.out.println(role.getName() +" uses Prayer of healing. Heals "+ action.getHeal() +" hit points to "+ action.getTargets().get(0).getName() +".");
            }
        }

    }

    /**
     * Prints the main combat stage for the monster
     * @param action class containing all the info from the attack/healing action taken by the monster
     * @param role the Participant that produces the attack (the one that attacks)
     */
    public void printAttackMonster(Action action, ParticipantsAdventure role) {
        System.out.println("\n");
        if(role.isBoss()){
            StringBuilder names = new StringBuilder();
            int i;
            for(i = 0; i < action.getTargets().size() - 1; i++){
                names.append(action.getTargets().get(i).getName());
                if(i + 1 != action.getTargets().size() - 1){
                    names.append(", ");
                }
            }
            names.append(" and ");
            names.append(action.getTargets().get(i).getName());
            System.out.println(role.getName() +" (Boss) attacks "+ names +".");
        }else{
            System.out.println(role.getName() +" attacks "+ action.getTargets().get(0).getName() +".");
        }
        if(action.getDamageType() == 1){
            System.out.println("Hits and deals "+ action.getDamage() +" "+ role.getDamageType() +" damage.");
        }
        if(action.getDamageType() == 0){
            System.out.println("Fails and deals 0 "+ role.getDamageType() +" damage.");
        }
        if(action.getDamageType() == 2){
            System.out.println("Critical hit and deals "+ action.getDamage() +" "+ role.getDamageType() +" damage.");
        }
    }

    /**
     * This method asks to the user the Character class when creating a Character
     * @return Character Class
     */
    public String getCharacterClass() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("-> Enter the character's initial class [Adventurer, Cleric, Wizard]: ");
        return scanner.nextLine();
    }

    /**
     * Prints when the character has been created
     * @param userName name of the new Character created
     */
    public void characterCreated(String userName) {
        System.out.println("\nThe new character "+ userName +" has been created.\n");
    }

    /**
     * Prints to the interface that a Monster ahs been killed
     * @param versus Array containing the name of the Monster and the name of the Character who killed it
     */
    public void killConfirm(ArrayList<ParticipantsAdventure> versus) {
        System.out.println(versus.get(1).getName() + " dies.");
    }

    /**
     * prints the introduction to the preparation Stage
     */
    public void preparationStageIntro() {
        System.out.println("-------------------------");
        System.out.println("*** Preparation stage ***");
        System.out.println("-------------------------");
    }

    /**
     * Prints second part of the Short-Rest stage for every character
     * @param c Character taking the action
     * @param strings string containing the type of action, number of healing points added and characters involved
     */
    public void restStageHealing(Character c, ArrayList<String> strings) {
        if(c.getHitPoints() == 0){
            System.out.println(c.getName() +" is unconscious.");
        }else{
            if(c.getCharacterClass().equals("Wizard")){
                System.out.println(c.getName() + strings.get(0));
            }else{
                if(c.getCharacterClass().equals("Paladin")){
                    System.out.println(c.getName() +" uses "+ strings.get(0) +". Heals "+ strings.get(1) +" hit points to " + strings.get(2));
                }else{
                    System.out.println(c.getName() +" uses "+ strings.get(0) +". Heals "+ strings.get(1) +" hit points.");
                }
            }
        }
    }
}